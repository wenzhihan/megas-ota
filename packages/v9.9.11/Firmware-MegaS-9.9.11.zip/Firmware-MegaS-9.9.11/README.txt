MCU A/B 双槽 OTA 测试包 / MCU-ONLY
==================================

本包只做 MCU 升级，不含任何 SOC（RK3568）镜像。

内容:
  MegaTest                 上位机（debug 版，含 mcu_ota_ver / mcu_ota_upd / mcu_boot / mcu_normal）
  megamcu_1.0.0.5.bin      MCU 完整镜像（boot 1.0.0.1 + AppA + AppB，各槽 1.0.0.5）
  deploy_mcu.sh             部署 MegaTest + 查活动槽 + 提取另一槽 + mcu_ota_upd + 复查
  manifest.json             元信息

为什么不用 flash_mcu:
  本板 MCU 的 ROM BOOT ISP 串口只引到 J57（给外部上位机），SOC 侧 /dev/ttyS7 打不通，
  整片擦写会把 bootloader 冲掉且无法从 SOC 恢复。正确的 SOC 侧升级是 IAP 双槽 OTA：
  App 发 $iap -> MCU 进 bootloader -> CMD_START 指定非活动槽 -> 2048B/包写入 -> CRC -> 切换。

槽位布局:
  boot 0x08000000 | cfg 0x6000 | OTA1 描述 0x6400 | App A 0x08007000 | App B 0x08043000 | NVS 0x0807F000
  每槽 240 KB；版本号在 槽基址+0x400

流程:
  1. 部署 MegaTest -> /home/cat/MegaTest（旧版备份 MegaTest.bak.<时间戳>）
  2. mcu_ota_ver 读当前活动槽（App A/B）
  3. 从 megamcu_1.0.0.5.bin 按偏移 dd 出「另一槽」的 240KB 镜像
  4. mcu_ota_upd /dev/ttyS3 <slot.bin>
  5. 复查活动槽是否翻转
