#!/bin/sh
# 包内 MCU 升级执行器（A/B 双槽 OTA 版，由 OTA 脚本解包后调用）
# 用法: sh deploy_mcu.sh <payload_root>
#   流程: 部署 MegaTest -> 查活动槽 -> 从完整镜像提取「另一槽」-> mcu_ota_upd -> 复查切换
#
# 说明: 本板 MCU 的 ROM BOOT ISP 串口只引出到 J57（外部上位机用），
#       SOC 侧 /dev/ttyS7 打不通，因此不能整片擦写；正路是 IAP 双槽 OTA。

set -u
ROOT="${1:-.}"
MT_SRC="$ROOT/MegaTest"
FULL_IMG="$ROOT/megamcu_1.0.0.5.bin"
APP_PORT="/dev/ttyS3"
WORK=/tmp/mcu_ota_stage

# 统一包布局：boot@0 + cfg@0x6000 + OTA1描述@0x6400 + AppA@0x7000 + AppB@0x43000
A_OFF_KB=28        # 0x7000  = 28672 = 28 KB
B_OFF_KB=268       # 0x43000 = 274432 = 268 KB
SLOT_KB=240        # 每槽 240 KB

log() { echo "[deploy_mcu] $*"; }
die() { log "!! $*"; exit 1; }

# ---------- 1. 部署 MegaTest ----------
if [ -f "$MT_SRC" ]; then
    log "部署 MegaTest -> /home/cat/MegaTest"
    if [ -f /home/cat/MegaTest ]; then
        BAK="/home/cat/MegaTest.bak.$(date +%Y%m%d_%H%M%S)"
        cp -f /home/cat/MegaTest "$BAK" && log "旧版本已备份: $BAK"
    fi
    cp -f "$MT_SRC" /home/cat/MegaTest.new || die "拷贝 MegaTest 失败"
    chmod 755 /home/cat/MegaTest.new
    mv -f /home/cat/MegaTest.new /home/cat/MegaTest
    log "MegaTest md5=$(md5sum /home/cat/MegaTest | awk '{print $1}')"
fi
MT=/home/cat/MegaTest
[ -x "$MT" ] || die "$MT 不可执行"

# ---------- 2. 查活动槽 ----------
log "查询当前活动槽..."
VER_OUT=$("$MT" mcu_ota_ver 2>&1)
echo "$VER_OUT" | sed 's/^/    /'
ACTIVE=$(echo "$VER_OUT" | grep -o 'App [AB]' | head -1 | awk '{print $2}')
[ -n "$ACTIVE" ] || die "无法解析活动槽（MCU 是否在跑？）"
log "当前活动槽: App $ACTIVE"

if [ "$ACTIVE" = "A" ]; then
    TARGET_OFF=$B_OFF_KB; TARGET_SLOT=B
else
    TARGET_OFF=$A_OFF_KB; TARGET_SLOT=A
fi
log "目标槽: App $TARGET_SLOT (offset ${TARGET_OFF}KB)"

# ---------- 3. 从完整镜像提取目标槽 ----------
[ -f "$FULL_IMG" ] || die "包内缺少完整镜像: $FULL_IMG"
log "完整镜像: $(basename "$FULL_IMG")  $(stat -c %s "$FULL_IMG") B  md5=$(md5sum "$FULL_IMG" | awk '{print $1}')"

mkdir -p "$WORK"
SLOT_BIN="$WORK/app_$TARGET_SLOT.bin"
dd if="$FULL_IMG" of="$SLOT_BIN" bs=1024 skip=$TARGET_OFF count=$SLOT_KB 2>/dev/null || die "提取槽镜像失败"
SLOT_VER=$(dd if="$SLOT_BIN" bs=1 skip=1024 count=4 2>/dev/null | od -An -tx1 | tr -d ' \n')
log "槽镜像: $(stat -c %s "$SLOT_BIN") B  ver(hex@0x400)=$SLOT_VER  md5=$(md5sum "$SLOT_BIN" | awk '{print $1}')"

# ---------- 4. 执行 OTA ----------
log "开始 A/B OTA -> App $TARGET_SLOT"
"$MT" mcu_ota_upd "$APP_PORT" "$SLOT_BIN"
RC=$?
log "mcu_ota_upd 返回 rc=$RC"
[ "$RC" -eq 0 ] || die "OTA 失败，MCU 仍运行在 App $ACTIVE 槽（未切换）"

# ---------- 5. 复查 ----------
sleep 2
log "OTA 后复查:"
"$MT" mcu_ota_ver 2>&1 | sed 's/^/    /'
NEW_ACTIVE=$("$MT" mcu_ota_ver 2>&1 | grep -o 'App [AB]' | head -1 | awk '{print $2}')
if [ "$NEW_ACTIVE" = "$TARGET_SLOT" ]; then
    log "OK: 活动槽已从 App $ACTIVE 切换到 App $TARGET_SLOT"
else
    log "WARN: 活动槽仍为 App ${NEW_ACTIVE:-?}，切换可能未生效"
fi

log "完成，rc=0"
exit 0
