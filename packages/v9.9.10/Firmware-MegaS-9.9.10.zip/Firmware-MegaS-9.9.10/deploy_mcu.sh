#!/bin/sh
# 包内 MCU 升级执行器（由 OTA 脚本在解包后调用）
# 用法: sh deploy_mcu.sh <payload_root>
#   职责: 1) 部署 MegaTest  2) MCU 进 BOOT  3) ISP 预检  4) flash_mcu 烧录  5) 退出 BOOT  6) 复查
#   安全: 预检不通过直接放弃，不动 Flash。

set -u
ROOT="${1:-.}"
MT_SRC="$ROOT/MegaTest"
MCU_BIN="$ROOT/mcu-megaS-20251220_0.0.1.bin"
ISP_PORT="/dev/ttyS7"
APP_PORT="/dev/ttyS3"
SYS=/sys/class/gpio
BOOT0=40          # GPIO1_B0  实测：本板 boot0 为 gpio40
RESET=22          # GPIO0_C6  实测：本板 reset 为 gpio22
# 注意：MegaTest 内置的 101/102 是「鲁班猫测试板」引脚，在本板对应
#       vdd_3v3_edp_tp / vcc5v0_usb20_hub，千万不要用！

log() { echo "[deploy_mcu] $*"; }
die() { log "!! $*"; exit 1; }

# ---------- 1. 部署 MegaTest ----------
if [ -f "$MT_SRC" ]; then
    log "部署 MegaTest -> /home/cat/MegaTest"
    if [ -f /home/cat/MegaTest ]; then
        BAK="/home/cat/MegaTest.bak.$(date +%Y%m%d_%H%M%S)"
        cp -f /home/cat/MegaTest "$BAK" && log "旧版本已备份: $BAK"
    fi
    cp -f "$MT_SRC" /home/cat/MegaTest.new || die "拷贝 MegaTest 失败"
    chmod 755 /home/cat/MegaTest.new
    mv -f /home/cat/MegaTest.new /home/cat/MegaTest
    log "MegaTest md5=$(md5sum /home/cat/MegaTest | awk '{print $1}')"
else
    log "包内无 MegaTest，跳过部署"
fi

[ -f "$MCU_BIN" ] || die "包内缺少 MCU 固件: $MCU_BIN"
log "MCU 固件: $(basename "$MCU_BIN")  $(stat -c %s "$MCU_BIN") B  md5=$(md5sum "$MCU_BIN" | awk '{print $1}')"

# ---------- 2. GPIO 准备 ----------
prep() {
    [ -d "$SYS/gpio$1" ] || echo "$1" > "$SYS/export" 2>/dev/null
    echo out > "$SYS/gpio$1/direction" 2>/dev/null
}
gset() { echo "$2" > "$SYS/gpio$1/value"; }
prep "$BOOT0" || die "export gpio$BOOT0 失败"
prep "$RESET" || die "export gpio$RESET 失败"

enter_boot() {
    gset "$BOOT0" 1; sleep 0.02
    gset "$RESET" 1; sleep 0.2
    gset "$RESET" 0; sleep 0.5
}
exit_boot() {
    gset "$BOOT0" 0; sleep 0.02
    gset "$RESET" 1; sleep 0.2
    gset "$RESET" 0; sleep 0.8
}

# ---------- 3. ISP 预检 (0x7F -> 期望 0x79) ----------
isp_preflight() {
    python3 - "$ISP_PORT" <<'PY'
import os, select, sys, termios, time
port = sys.argv[1]
fd = os.open(port, os.O_RDWR | os.O_NOCTTY | os.O_NONBLOCK)
a = termios.tcgetattr(fd); a[0] = 0; a[1] = 0
a[2] = termios.CS8 | termios.CREAD | termios.CLOCAL; a[3] = 0
a[4] = getattr(termios, "B9600"); a[5] = a[4]
a[6][termios.VMIN] = 0; a[6][termios.VTIME] = 0
termios.tcsetattr(fd, termios.TCSANOW, a)
termios.tcflush(fd, termios.TCIOFLUSH)
time.sleep(0.05); os.write(fd, b"\x7f")
buf = b""; t0 = time.time()
while time.time() - t0 < 1.0:
    r, _, _ = select.select([fd], [], [], 0.1)
    if r:
        buf += os.read(fd, 64)
os.close(fd)
print(buf.hex(" ") if buf else "NONE")
PY
}

log "进入 BOOT 模式 (BOOT0=$BOOT0=1, RESET=$RESET 脉冲)"
enter_boot
ACK=$(isp_preflight)
log "ISP 预检应答: $ACK"

case "$ACK" in
    79*)
        log "ISP 握手成功，开始烧录"
        ;;
    *)
        log "!! MCU 未应答，放弃烧录（Flash 未被改动）"
        exit_boot
        die "ISP preflight 失败：请检查 MCU 供电 / J57 接线 / ttyS7"
        ;;
esac

# ---------- 4. 烧录 ----------
log "调用 MegaTest flash_mcu $ISP_PORT <bin>"
/home/cat/MegaTest flash_mcu "$ISP_PORT" "$MCU_BIN"
RC=$?
log "flash_mcu 返回 rc=$RC"

# ---------- 5. 退出 BOOT ----------
log "退出 BOOT，恢复正常运行"
exit_boot

# ---------- 6. 复查应用口 ----------
if [ "$RC" -eq 0 ]; then
    sleep 1
    python3 - "$APP_PORT" <<'PY'
import os, select, sys, termios, time
port = sys.argv[1]
try:
    fd = os.open(port, os.O_RDWR | os.O_NOCTTY | os.O_NONBLOCK)
except Exception as e:
    print("app probe open fail:", e); raise SystemExit
a = termios.tcgetattr(fd); a[0] = 0; a[1] = 0
a[2] = termios.CS8 | termios.CREAD | termios.CLOCAL; a[3] = 0
a[4] = termios.B115200; a[5] = termios.B115200
a[6][termios.VMIN] = 0; a[6][termios.VTIME] = 0
termios.tcsetattr(fd, termios.TCSANOW, a)
termios.tcflush(fd, termios.TCIOFLUSH)
os.write(fd, b"?")
buf = b""; t0 = time.time()
while time.time() - t0 < 1.5:
    r, _, _ = select.select([fd], [], [], 0.1)
    if r:
        buf += os.read(fd, 256)
os.close(fd)
print("app '?' ->", repr(buf[:120]) if buf else "<无应答>")
PY
fi

log "完成，rc=$RC"
exit "$RC"
