MCU 升级测试包 / MCU-ONLY
=========================

本包只做 MCU 升级，不含任何 SOC（RK3568）镜像。

内容:
  MegaTest                        上位机工具（debug 版，含 mcu_boot/mcu_normal/mcu_boot_test）
  mcu-megaS-20251220_0.0.1.bin    MCU 固件（N32G452，烧到 0x08000000）
  deploy_mcu.sh                   部署 MegaTest + 进 BOOT + ISP 预检 + flash_mcu + 退出 BOOT
  manifest.json                   元信息

流程:
  1. 部署 MegaTest -> /home/cat/MegaTest（旧版备份为 MegaTest.bak.<时间戳>）
  2. GPIO40(BOOT0)=1 -> GPIO22(RESET) 脉冲 -> MCU 进出厂 ROM BOOT
  3. ttyS7 @9600 发 0x7F，期望 0x79；不应答则放弃，不改动 Flash
  4. MegaTest flash_mcu /dev/ttyS7 <bin>（erase 256 页 + 128B 分包 + CRC32 校验）
  5. BOOT0=0 + 复位 -> 回应用模式
  6. ttyS3 @115200 发 '?' 复查

注意:
  * MegaTest 内置的 101/102 引脚是「鲁班猫测试板」用的，本板 101=vdd_3v3_edp_tp、
    102=vcc5v0_usb20_hub（内核占用）。本板必须用 40/22，deploy_mcu.sh 已按 40/22 实现。
  * 不要用 MegaTest mcu_boot / mcu_normal，它们走的是 101/102。
