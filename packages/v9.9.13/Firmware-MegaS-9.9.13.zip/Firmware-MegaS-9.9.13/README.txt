MCU A/B 双槽 OTA 测试包 v9.9.13 / MCU-ONLY
=========================================

相对 v9.9.12 的关键修复（重要，v9.9.12 的停服务其实没生效）:
  !! ntmega.service 是 Type=oneshot + RemainAfterExit=yes，run.sh 启动完即退出；
     Core/Device 以 root 身份 daemonize（PPID=1）已脱离 systemd cgroup。
     所以 v9.9.12 里 cat 用户执行 `systemctl stop` / `kill` 全部静默失败
     （stop 返回 0 但 is-active 仍是 active，kill 报 EPERM 被 2>/dev/null 吞掉），
     Core 继续独占 /dev/ttyS3 -> mcu_ota_ver 无应答、OTA 必然失败。
  + 探测免密 sudo（sudo -n true），所有 systemctl / kill 走 sudo -n
  + 停止后校验：Core/Device 真正消失（实测 1s 内），日志打印 ntmega=inactive
  + kill -9 兜底后仍存活则直接判失败退出（不再假装成功）
  + 恢复服务后轮询 is-active，并做 1888(Core) / 1889(Device) 健康检查
  + mcu_ota_upd 加 timeout 240 保护

内容:
  MegaTest                 上位机（debug 版，含 mcu_ota_ver / mcu_ota_upd）
  megamcu_1.0.0.5.bin      MCU 完整镜像（boot 1.0.0.1 + AppA/AppB 各 1.0.0.5）
  deploy_mcu.sh             停服务 -> 查活动槽 -> 提取另一槽 -> mcu_ota_upd -> 复查 -> 恢复服务
  manifest.json             元信息

布局: boot 0x08000000 | AppA 0x08007000(28KB) | AppB 0x08043000(268KB) | 每槽 240KB
服务: 升级期间停 ntmega 并结束 root 的 Core/Device；EXIT/INT/TERM 均恢复
