#!/bin/sh
# MCU A/B OTA 公共函数库（抗干扰 / 回退 / 进度条执行器）
#
# 调用方需先定义/导出:
#   MT APP_PORT WORK SUDO OTA_PY IMG4 IMG5 A_OFF B_OFF SLOT_KB
#   LOG()              日志函数
#   ORIG_SLOT ORIG_VER 回退目标（每次升级前由调用方写入）
#
# 提供:
#   read_state          查询活动槽/版本（写入 STATE_SLOT/STATE_VER/STATE_RAW）
#   liveness            test_grbl 活性探测
#   extract_slot        从完整镜像提取指定槽
#   ota_run             带进度条的单次 OTA
#   guard_start/stop    OTA 期间的串口独占守卫
#   reset_mcu           MCU 硬件复位（BOOT0=gpio40 / RESET=gpio22）
#   rollback            回退到 ORIG_SLOT/ORIG_VER
#   attempt_upgrade     重试 + 回退 + 断言

# ---------------- 状态查询 ----------------
read_state() {
    STATE_RAW=$(timeout 15 "$MT" mcu_ota_ver 2>&1)
    STATE_SLOT=$(printf '%s\n' "$STATE_RAW" | grep -o 'App [AB]' | head -1 | awk '{print $2}')
    STATE_VER=$(printf '%s\n' "$STATE_RAW" | grep -o 'v[0-9]\+\.[0-9]\+\.[0-9]\+\.[0-9]\+' | head -1)
    [ -n "$STATE_SLOT" ]
}

liveness() {
    timeout 15 "$MT" test_grbl 2>&1 | grep -q 'ok'
}

# ---------------- 干扰防护 ----------------
# OTA 期间若 Core/Device 被 ntmega 看门狗或其它脚本意外拉起，
# 会抢走 /dev/ttyS3 造成传输错包；守卫每 2s 巡检并即时清掉。
guard_start() {
    rm -f "$WORK/guard.stop" "$WORK/guard.pid" 2>/dev/null
    (
        while [ ! -f "$WORK/guard.stop" ]; do
            sleep 2
            [ -f "$WORK/guard.stop" ] && break
            for P in $(ps -eo pid,comm | awk '$2=="Core" || $2=="Device" {print $1}'); do
                $SUDO kill -9 "$P" 2>/dev/null && echo "$(date +%T) [guard] 清除意外拉起的进程 pid=$P"
            done
        done
    ) > "$WORK/guard.log" 2>&1 &
    GUARD_PID=$!
    echo "$GUARD_PID" > "$WORK/guard.pid"
}

guard_stop() {
    # 用停止文件 + PID 双保险，避免残留守卫在服务恢复后继续杀 Core/Device
    touch "$WORK/guard.stop" 2>/dev/null
    for P in ${GUARD_PID:-} $(cat "$WORK/guard.pid" 2>/dev/null); do
        kill -9 "$P" 2>/dev/null
    done
    GUARD_PID=""
}

# MCU 硬件复位：优先用 MegaTest mcu_normal（内部用 GPIO40/22），
# 失败则退回 sysfs 直接拉 RESET(gpio22)。
reset_mcu() {
    if timeout 10 "$MT" mcu_normal >/dev/null 2>&1; then
        return 0
    fi
    $SUDO sh -c '
        G=/sys/class/gpio
        [ -d $G/gpio22 ] || echo 22 > $G/export 2>/dev/null
        [ -d $G/gpio22 ] || exit 1
        echo out > $G/gpio22/direction 2>/dev/null
        echo 1 > $G/gpio22/value; sleep 0.1; echo 0 > $G/gpio22/value; sleep 0.2; echo 1 > $G/gpio22/value
    ' >/dev/null 2>&1
}

# ---------------- 镜像 / 执行 ----------------
extract_slot() {          # $1=A|B  $2=1.0.0.4|1.0.0.5  $3=输出文件
    if [ "$1" = "A" ]; then OFF=$A_OFF; else OFF=$B_OFF; fi
    if [ "$2" = "1.0.0.4" ]; then IMG=$IMG4; else IMG=$IMG5; fi
    [ -f "$IMG" ] || return 1
    dd if="$IMG" of="$3" bs=1024 skip=$OFF count=$SLOT_KB 2>/dev/null || return 1
    [ -s "$3" ]
}

ota_run() {               # $1=槽镜像 $2=日志 $3=标题 $4=style
    python3 "$OTA_PY" --mt "$MT" --port "$APP_PORT" --bin "$1" \
        --log "$2" --style "${4:-log}" --title "$3" --timeout 240
}

# ---------------- 回退 ----------------
# 目标：回到 ORIG_SLOT / vORIG_VER 且 test_grbl 正常。
# A/B 双槽下若失败发生在 CMD_START 之前或传输途中，活动槽本来就不会变，
# 此时回退=确认状态即可（这是最常见路径）。
# 若已被切到半写槽，则用 ORIG_VER 镜像反复写「当前非活动槽」直到切回。
rollback() {
    LOG "触发抗干扰回退：目标 App ${ORIG_SLOT:-?} / v${ORIG_VER:-?}"
    guard_stop
    i=0
    while [ $i -lt 3 ]; do
        read_state && break
        LOG "  回退: MCU 无应答，执行硬件复位 ($((i+1))/3)"
        reset_mcu
        sleep 2
        i=$((i+1))
    done
    if ! read_state; then
        LOG "  !! 回退失败：复位 3 次后仍无应答"
        return 1
    fi

    j=0
    while [ $j -lt 3 ]; do
        if [ "$STATE_SLOT" = "$ORIG_SLOT" ] && [ "$STATE_VER" = "v$ORIG_VER" ]; then
            if liveness; then
                LOG "  回退完成：App $STATE_SLOT / $STATE_VER，活性 OK（A/B 双槽保护生效）"
                return 0
            fi
            LOG "  版本已复原但活性检测失败，继续尝试复位"
            reset_mcu; sleep 2; read_state || return 1
        fi
        if [ "$STATE_SLOT" = "A" ]; then TGT=B; else TGT=A; fi
        RB_BIN="$WORK/rollback_${j}_${TGT}_${ORIG_VER}.bin"
        if ! extract_slot "$TGT" "$ORIG_VER" "$RB_BIN"; then
            LOG "  !! 回退失败：找不到 v$ORIG_VER 镜像，无法重建 App $TGT"
            return 1
        fi
        LOG "  回退 OTA $((j+1))/3: 写 App $TGT <- v$ORIG_VER"
        guard_start
        ota_run "$RB_BIN" "$WORK/rollback_${j}.log" "RB$((j+1))" log
        RRC=$?
        guard_stop
        sleep 2
        read_state || { reset_mcu; sleep 2; read_state || return 1; }
        LOG "  回退后: App $STATE_SLOT / $STATE_VER (rc=$RRC)"
        j=$((j+1))
    done
    LOG "  !! 回退失败：3 次回退 OTA 后仍未复原"
    return 1
}

# ---------------- 带重试与回退的单次升级 ----------------
# $1=目标版本 $2=目标槽 $3=槽镜像 $4=编号
# 返回 0=成功；失败时会先调用 rollback
attempt_upgrade() {
    TV=$1; TGT=$2; SLOT_BIN=$3; N=$4
    ATT=1
    while [ $ATT -le 3 ]; do
        LOG "  OTA 尝试 $ATT/3 -> App $TGT / v$TV"
        guard_start
        ota_run "$SLOT_BIN" "$WORK/ota_${N}_a${ATT}.log" "N${N}/A${ATT}" log
        RC=$?
        guard_stop
        sleep 2
        if read_state; then
            GOT="$STATE_SLOT/$STATE_VER"
        else
            GOT="无应答"
        fi
        if [ "$RC" -eq 0 ] && [ "$STATE_SLOT" = "$TGT" ] && [ "$STATE_VER" = "v$TV" ]; then
            if liveness; then
                LOG "  尝试 $ATT 成功: App $TGT / v$TV，活性 OK (rc=$RC)"
                return 0
            fi
            LOG "  尝试 $ATT: 槽位/版本正确但活性检测失败，按干扰处理"
        else
            LOG "  尝试 $ATT 失败: rc=$RC 期望 App $TGT/v$TV 实得 $GOT"
        fi
        # 清场后重试：确保没有残留 OTA 进程，复位 MCU
        pkill -9 -f mcu_ota_upd 2>/dev/null
        reset_mcu
        sleep 2
        ATT=$((ATT+1))
    done
    LOG "  3 次尝试均失败，进入回退流程"
    rollback
    return 1
}
