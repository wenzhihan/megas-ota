#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""单次 MCU A/B OTA 执行器：实时进度条 + 阶段显示 + 超时保护 + 状态文件

用法:
  python3 ota_once.py --mt /usr/bin/MegaTest --port /dev/ttyS3 \
      --bin /tmp/app_B.bin --log /tmp/ota.log [--style bar|log] [--timeout 240]

输出:
  stderr: 进度条（bar 模式用 \\r 覆盖；log 模式每个进度点打印一行）
  --log :  MegaTest 原始输出（逐行实时落盘）
  --log + ".status": rc= / packets= / target_slot= / elapsed_ms= / ok=

退出码: 0=成功, 1=OTA 失败, 124=超时, 2=参数错误
"""
import argparse
import os
import re
import select
import subprocess
import sys
import time

RE_PROGRESS = re.compile(r"进度:\s*(\d+)\s*/\s*(\d+)\s*包\s*\((\d+)%\)")
RE_TARGET = re.compile(r"CMD_START确认.*?App\s*([AB])")
RE_OK = re.compile(r"\[OK\]\s*OTA升级成功")
RE_FAIL = re.compile(r"\[FAIL\]|OTA升级失败|校验失败|写入失败|CRC.*失败|超时|timeout|Error:", re.I)
RE_STEP1 = re.compile(r"\[步骤1\]")
RE_BOOT = re.compile(r"Bootloader就绪")
RE_START = re.compile(r"发送CMD_START")
RE_TIMING = re.compile(r"总耗时:\s*(\d+)\s*ms")

STAGES = [
    ("init", "初始化"),
    ("handshake", "握手 $iap"),
    ("bootloader", "Bootloader 就绪"),
    ("erase", "擦除 / CMD_START"),
    ("transfer", "数据传输"),
    ("verify", "校验 + 重启"),
    ("done", "完成"),
]

SPINNER = ["|", "/", "-", "\\"]


def bar(pct, width=30):
    filled = int(round(pct * width / 100.0))
    return "[" + "█" * filled + "░" * (width - filled) + "]"


def emit(msg, style, stream=sys.stderr):
    stream.write(msg)
    stream.flush()


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--mt", default="/usr/bin/MegaTest")
    ap.add_argument("--port", default="/dev/ttyS3")
    ap.add_argument("--bin", required=True)
    ap.add_argument("--log", required=True)
    ap.add_argument("--style", choices=["bar", "log"], default="bar")
    ap.add_argument("--timeout", type=float, default=240.0)
    ap.add_argument("--title", default="")
    a = ap.parse_args()

    if not os.path.isfile(a.bin):
        emit("[ota_once] 固件不存在: %s\n" % a.bin, a.style)
        return 2

    t0 = time.monotonic()
    stage = "init"
    cur_pkt = 0
    total_pkt = 120
    pct = 0
    target_slot = ""
    ok_mark = False
    fail_mark = False
    spin_idx = 0
    last_draw = 0.0
    last_pct = -1

    cmd = ["stdbuf", "-oL", "-eL", a.mt, "mcu_ota_upd", a.port, a.bin]
    proc = subprocess.Popen(cmd, stdout=subprocess.PIPE, stderr=subprocess.STDOUT,
                            bufsize=0, close_fds=True)
    logf = open(a.log, "w", encoding="utf-8", errors="replace", buffering=1)

    def draw(final=False):
        nonlocal last_draw, spin_idx, last_pct
        elapsed = time.monotonic() - t0
        if pct > 0 and cur_pkt < total_pkt:
            eta = elapsed * (total_pkt - cur_pkt) / max(cur_pkt, 1)
            eta_s = "ETA %5.1fs" % eta
        else:
            eta_s = "         "
        sname = dict(STAGES).get(stage, stage)
        spin = SPINNER[spin_idx % len(SPINNER)] if (stage == "transfer" and not final) else " "
        prefix = ("[%s] " % a.title) if a.title else ""
        line = "%s%-11s %s %3d%% %3d/%-3d 包  %6.1fs  %s %s" % (
            prefix, sname, bar(pct), pct, cur_pkt, total_pkt, elapsed, eta_s, spin)
        if a.style == "bar":
            emit("\r" + line + ("\n" if final else ""), a.style)
        elif final or pct != last_pct:
            emit(line.rstrip() + "\n", a.style)
        last_pct = pct
        last_draw = time.monotonic()

    def handle(line):
        nonlocal stage, cur_pkt, total_pkt, pct, target_slot, ok_mark, fail_mark
        m = RE_PROGRESS.search(line)
        if m:
            cur_pkt, total_pkt, pct = int(m.group(1)), int(m.group(2)), int(m.group(3))
            stage = "transfer"
            draw()
            return
        if RE_TARGET.search(line):
            target_slot = RE_TARGET.search(line).group(1)
        if RE_STEP1.search(line):
            stage = "handshake"; draw()
        elif RE_BOOT.search(line):
            stage = "bootloader"; draw()
        elif RE_START.search(line):
            stage = "erase"; draw()
        elif RE_OK.search(line):
            ok_mark = True; stage = "verify"
        elif RE_FAIL.search(line):
            fail_mark = True
        elif "校验" in line or "重启" in line:
            if stage == "transfer":
                stage = "verify"

    rc = 124
    try:
        draw()
        while True:
            elapsed = time.monotonic() - t0
            if elapsed > a.timeout:
                emit("\n[ota_once] !! 超时 %.0fs，终止 OTA 子进程\n" % a.timeout, a.style)
                proc.kill()
                rc = 124
                break
            ready, _, _ = select.select([proc.stdout], [], [], 0.2)
            if ready:
                raw = proc.stdout.readline()
                if not raw:
                    rc = proc.wait()
                    break
                line = raw.decode("utf-8", "replace").rstrip("\r\n")
                logf.write(line + "\n")
                handle(line)
            else:
                if stage == "transfer" and time.monotonic() - last_draw > 0.2:
                    spin_idx += 1
                    draw()
        else:
            rc = proc.wait()
    except KeyboardInterrupt:
        proc.kill()
        rc = 130
    finally:
        logf.flush()
        logf.close()
        try:
            if proc.poll() is None:
                proc.kill()
            proc.wait()
        except Exception:
            pass

    if stage != "done":
        stage = "done" if (rc == 0 and ok_mark) else stage
    pct = 100 if (rc == 0 and ok_mark) else pct
    draw(final=True)

    ok = (rc == 0 and ok_mark and not fail_mark)
    status = {
        "rc": rc if not ok else 0,
        "proc_rc": rc,
        "ok": 1 if ok else 0,
        "ok_mark": int(ok_mark),
        "fail_mark": int(fail_mark),
        "packets": cur_pkt,
        "total": total_pkt,
        "pct": pct,
        "target_slot": target_slot,
        "elapsed_ms": int((time.monotonic() - t0) * 1000),
    }
    with open(a.log + ".status", "w", encoding="utf-8") as f:
        for k, v in status.items():
            f.write("%s=%s\n" % (k, v))

    emit("[ota_once] 结果: %s  rc=%d  %d/%d 包  %d ms  目标槽=App %s\n" % (
        "OK" if ok else "FAIL", status["rc"], cur_pkt, total_pkt,
        status["elapsed_ms"], target_slot or "?"), a.style)
    return 0 if ok else (124 if rc == 124 else 1)


if __name__ == "__main__":
    sys.exit(main())
