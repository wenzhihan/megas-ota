MCU A/B 双槽 OTA 测试包 v9.9.16 / MCU-ONLY
=========================================

本版新增（对应「升级进度条 + 抗干扰回退」）
------------------------------------------
1) 实时升级进度条 —— ota_once.py
   - 用 stdbuf -oL 让 MegaTest 行缓冲输出，逐行解析真实包数
     （[OTA] 进度: 20/120 包 (16%) ... 共 6 个进度点）。
   - 渲染 30 格进度条 + 阶段（握手/Bootloader/擦除/传输/校验重启）
     + 百分比 + 已完成包数 + 已耗时 + ETA；两个进度点之间用 spinner
     表示传输仍在进行，不伪造百分比。
   - --style bar（终端 \\r 覆盖）/ --style log（后台压测逐行打印）。
   - 内置 240s 超时保护；产出 <log>.status（rc/packets/target_slot/elapsed_ms）。

2) 抗干扰 —— lib_ota.sh
   - 串口独占守卫 guard_start/stop：OTA 期间每 2s 巡检，若 Core/Device
     被 ntmega 看门狗或其它脚本意外拉起，立即 kill -9，防止抢 /dev/ttyS3
     造成错包。用 guard.stop 文件 + PID 双保险，避免残留守卫在服务恢复后
     继续杀 Core。
   - 单次升级最多 3 次尝试；每次失败先 pkill 残留 OTA 进程、硬件复位 MCU
     （mcu_normal，BOOT0=gpio40 / RESET=gpio22）、再重试。
   - 每次成功后除校验「槽位翻转 + 版本号」外，还跑 test_grbl 做活性断言。

3) 自动回退 —— rollback()
   - 升级前记录 ORIG_SLOT / ORIG_VER 作为回退基准。
   - 失败时：先硬件复位 + 查询活动槽；若仍是原槽/原版本（A/B 双槽下
     传输中断的常见情况）→ 活性 OK 即判定「回退完成」，无需重写 flash。
   - 若已被切到半写槽 → 用 ORIG_VER 镜像写当前非活动槽并再 OTA，
     最多 3 次，直到回到原状态；全程带活性断言。
   - 包内自带 1.0.0.4 / 1.0.0.5 两份完整镜像，回退不依赖设备上残留文件。

历史修复（v9.9.13~15，全部保留）
--------------------------------
- ntmega.service = Type=oneshot + RemainAfterExit=yes + User=root；
  Core/Device 以 root daemonize（PPID=1）脱离 cgroup，cat 直接
  systemctl stop / kill 全部静默失败 → 所有操作走 sudo -n。
- 工作目录用 /tmp/mcu_ota_stage.$$（PID 隔离）+ EXIT 清理，避免 root
  属主残留目录导致 dd EACCES；dd stderr 回显、空文件校验。
- OTA 子进程后台执行并记 PID，收到 INT/TERM 先杀子进程再恢复服务，
  避免 MegaTest 变孤儿继续占串口。
- 恢复服务后轮询 is-active，并做 1888(Core)/1889(Device) 健康检查。

内容
----
  MegaTest                 上位机（debug 版，含 mcu_ota_ver / mcu_ota_upd）
  megamcu_1.0.0.4.bin      MCU 完整镜像（用于回退 / 降级）
  megamcu_1.0.0.5.bin      MCU 完整镜像（升级目标）
  ota_once.py              单次 OTA 执行器（进度条 / 超时 / status 文件）
  lib_ota.sh               抗干扰 / 回退 / 状态查询公共库
  deploy_mcu.sh            主流程：停服务 -> 查原槽 -> 提取另一槽 -> 带进度条 OTA
                           -> 复查+活性 -> 回退保障 -> 恢复服务
  manifest.json            元信息

布局: boot 0x08000000 | AppA 0x08007000(28KB) | AppB 0x08043000(268KB) | 每槽 240KB
服务: 升级期间停 ntmega 并结束 root 的 Core/Device；EXIT/INT/TERM 均恢复
