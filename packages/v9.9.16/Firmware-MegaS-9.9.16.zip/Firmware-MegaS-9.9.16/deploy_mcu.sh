#!/bin/sh
# 包内 MCU 升级执行器 v9.9.16（A/B 双槽 OTA）
#   用法: sh deploy_mcu.sh <payload_root>
#   新增: 实时进度条(ota_once.py) + 抗干扰(串口守卫/重试) + 失败自动回退(lib_ota.sh)
#
# 说明: 本板 MCU 的 ROM BOOT ISP 串口只引到 J57，SOC 侧打不通，
#       不能整片擦写；正路是 IAP 双槽 OTA（写非活动槽 -> CRC -> 切槽）。
set -u

ROOT="${1:-.}"
HERE=$(cd "$(dirname "$0")" && pwd)
APP_PORT=/dev/ttyS3
WORK="/tmp/mcu_ota_stage.$$"
A_OFF=28; B_OFF=268; SLOT_KB=240

log() { echo "[deploy_mcu] $*"; }
die() { log "!! $*"; exit 1; }
LOG() { log "$*"; }   # lib_ota.sh 使用的日志钩子

# ---------------- 服务停 / 恢复 ----------------
# ntmega.service = Type=oneshot + RemainAfterExit=yes，run.sh 退出后
# Core/Device 以 root daemonize（PPID=1）脱离 cgroup -> 必须 sudo
NTMEGA_WAS_ACTIVE=$(systemctl is-active ntmega 2>/dev/null || echo inactive)
SUDO=""
if [ "$(id -u)" != "0" ]; then
    if sudo -n true 2>/dev/null; then SUDO="sudo -n"; else log "WARN: 无免密 sudo"; fi
fi
log "ntmega 升级前状态: $NTMEGA_WAS_ACTIVE  提权方式: ${SUDO:-直接执行}"

stop_services() {
    log "停止 ntmega 并结束 Core/Device，释放 $APP_PORT"
    $SUDO systemctl stop ntmega >/dev/null 2>&1
    for P in $(ps -eo pid,comm | awk '$2=="Core" || $2=="Device" {print $1}'); do
        $SUDO kill -TERM "$P" 2>/dev/null
    done
    i=0
    while [ $i -lt 20 ]; do
        if ! pgrep -x Core >/dev/null 2>&1 && ! pgrep -x Device >/dev/null 2>&1; then
            log "  Core/Device 已退出 (ntmega=$(systemctl is-active ntmega 2>/dev/null))"
            return 0
        fi
        sleep 0.5; i=$((i+1))
    done
    log "  WARN: 未在 10s 内退出，强制 kill -9"
    for P in $(ps -eo pid,comm | awk '$2=="Core" || $2=="Device" {print $1}'); do
        $SUDO kill -9 "$P" 2>/dev/null
    done
    sleep 1
    if pgrep -x Core >/dev/null 2>&1 || pgrep -x Device >/dev/null 2>&1; then
        die "无法结束 Core/Device（权限不足），$APP_PORT 仍被占用"
    fi
}

start_services() {
    if [ "$NTMEGA_WAS_ACTIVE" = "active" ]; then
        log "恢复 ntmega 服务"
        $SUDO systemctl start ntmega >/dev/null 2>&1
        i=0
        while [ $i -lt 20 ]; do
            [ "$(systemctl is-active ntmega 2>/dev/null)" = "active" ] && break
            sleep 0.5; i=$((i+1))
        done
        log "  ntmega=$(systemctl is-active ntmega 2>/dev/null)"
        ps -eo pid,user,comm | awk '$3=="Core" || $3=="Device" {print "    "$0}'
        for U in 1888 1889; do
            if curl -s -m 3 "http://localhost:$U/test" >/dev/null 2>&1; then
                log "  端口 $U OK"
            else
                log "  WARN: 端口 $U 无响应"
            fi
        done
    else
        log "  ntmega 升级前未运行，保持不动"
    fi
}

cleanup() {
    touch "$WORK/guard.stop" 2>/dev/null
    guard_stop 2>/dev/null
    pkill -9 -f mcu_ota_upd 2>/dev/null
    start_services
    [ -n "${WORK:-}" ] && [ -d "$WORK" ] && rm -rf "$WORK" 2>/dev/null
}
trap 'log "收到中断信号，终止 OTA 并恢复服务"; touch "$WORK/guard.stop" 2>/dev/null; pkill -9 -f mcu_ota_upd 2>/dev/null; guard_stop 2>/dev/null; exit 130' INT TERM
trap 'cleanup' EXIT

rm -rf "$WORK" 2>/dev/null
mkdir -p "$WORK" 2>/dev/null || die "无法创建工作目录 $WORK"
[ -w "$WORK" ] || die "工作目录不可写: $WORK"

stop_services

# ---------------- 装载公共库 ----------------
[ -f "$HERE/lib_ota.sh" ] || die "缺少 lib_ota.sh"
[ -f "$HERE/ota_once.py" ] || die "缺少 ota_once.py"
. "$HERE/lib_ota.sh"

# 定位 MegaTest（包内优先部署）
MT=/home/cat/MegaTest
if [ -f "$ROOT/MegaTest" ]; then
    M_SRC=$(md5sum "$ROOT/MegaTest" | awk '{print $1}')
    M_DST=$(md5sum "$MT" 2>/dev/null | awk '{print $1}')
    if [ "$M_SRC" != "$M_DST" ]; then
        log "部署 MegaTest -> $MT"
        cp -f "$ROOT/MegaTest" "$MT.new" || die "拷贝 MegaTest 失败"
        chmod 755 "$MT.new"
        mv -f "$MT.new" "$MT" || die "替换 MegaTest 失败"
    else
        log "MegaTest 已是同版本（md5=$M_SRC），跳过部署"
    fi
fi
[ -x "$MT" ] || die "$MT 不可执行"

OTA_PY="$HERE/ota_once.py"
IMG5="$ROOT/megamcu_1.0.0.5.bin"
IMG4="$ROOT/megamcu_1.0.0.4.bin"
[ -f "$IMG5" ] || die "包内缺少 $IMG5"
# 回退镜像：优先包内，其次设备上已存的同版本镜像
[ -f "$IMG4" ] || IMG4=/home/cat/megamcu_1.0.0.4.bin

# ---------------- 等串口可用 ----------------
i=0
while [ $i -lt 10 ]; do
    read_state && break
    sleep 0.5; i=$((i+1))
done
read_state || die "MCU 无应答（串口未释放？）"
ORIG_SLOT=$STATE_SLOT
ORIG_VER=$(printf '%s' "$STATE_VER" | sed 's/^v//')
log "升级前: App $ORIG_SLOT / $STATE_VER  (回退基准)"

if [ "$ORIG_SLOT" = "A" ]; then TGT=B; else TGT=A; fi
TV=1.0.0.5
SLOT_BIN="$WORK/app_${TGT}_${TV}.bin"
extract_slot "$TGT" "$TV" "$SLOT_BIN" || die "提取 App $TGT 槽镜像失败"
log "目标: App $TGT / v$TV   槽镜像 $(stat -c %s "$SLOT_BIN") B  md5=$(md5sum "$SLOT_BIN" | awk '{print $1}')"

# ---------------- 执行（含进度条 / 抗干扰 / 回退）----------------
if attempt_upgrade "$TV" "$TGT" "$SLOT_BIN" 1; then
    log "OTA 成功：App $ORIG_SLOT -> App $TGT/v$TV"
    RC=0
else
    log "!! OTA 失败且回退结果见上；MCU 状态: App ${STATE_SLOT:-?}/${STATE_VER:-?}"
    RC=1
fi

# ---------------- 最终状态 ----------------
read_state && log "最终 MCU: App $STATE_SLOT / $STATE_VER"
log "完成，rc=$RC"
exit $RC
