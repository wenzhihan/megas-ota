#!/bin/sh
# 包内 MCU 升级执行器（A/B 双槽 OTA 版，由 OTA 脚本解包后调用）
# 用法: sh deploy_mcu.sh <payload_root>
#   流程: 部署 MegaTest -> 查活动槽 -> 从完整镜像提取「另一槽」-> mcu_ota_upd -> 复查切换
#
# 说明: 本板 MCU 的 ROM BOOT ISP 串口只引出到 J57（外部上位机用），
#       SOC 侧 /dev/ttyS7 打不通，因此不能整片擦写；正路是 IAP 双槽 OTA。

set -u
ROOT="${1:-.}"
MT_SRC="$ROOT/MegaTest"
FULL_IMG="$ROOT/megamcu_1.0.0.5.bin"
APP_PORT="/dev/ttyS3"
WORK="/tmp/mcu_ota_stage.$$"   # 用 PID 隔离，避免残留目录属主不一致（如曾以 root 跑过）

# 统一包布局：boot@0 + cfg@0x6000 + OTA1描述@0x6400 + AppA@0x7000 + AppB@0x43000
A_OFF_KB=28        # 0x7000  = 28672 = 28 KB
B_OFF_KB=268       # 0x43000 = 274432 = 268 KB
SLOT_KB=240        # 每槽 240 KB

log() { echo "[deploy_mcu] $*"; }
die() { log "!! $*"; exit 1; }

# ---------- 0. 停服务：OTA 期间必须让 Core 放开 ttyS3 ----------
# 注意: ntmega.service 是 Type=oneshot + RemainAfterExit=yes，run.sh 启动完即退出，
#       Core/Device 以 root 身份 daemonize（PPID=1）脱离了 cgroup。
#       因此 cat 用户直接 `systemctl stop` / `kill` 会静默失败，必须走 sudo。
NTMEGA_WAS_ACTIVE=$(systemctl is-active ntmega 2>/dev/null || echo inactive)
log "ntmega 升级前状态: $NTMEGA_WAS_ACTIVE"

SUDO=""
if [ "$(id -u)" != "0" ]; then
    if sudo -n true 2>/dev/null; then
        SUDO="sudo -n"
    else
        log "WARN: 当前用户无免密 sudo，可能无法结束 root 的 Core/Device"
    fi
fi
log "提权方式: ${SUDO:-直接执行}"

stop_services() {
    log "停止 ntmega 并结束 Core/Device，释放 $APP_PORT"
    $SUDO systemctl stop ntmega >/dev/null 2>&1
    for P in $(ps -eo pid,comm | awk '$2=="Core" || $2=="Device" {print $1}'); do
        $SUDO kill -TERM "$P" 2>/dev/null
    done
    i=0
    while [ $i -lt 20 ]; do
        if ! pgrep -x Core >/dev/null 2>&1 && ! pgrep -x Device >/dev/null 2>&1; then
            log "Core/Device 已退出 (ntmega=$(systemctl is-active ntmega 2>/dev/null))"
            return 0
        fi
        sleep 0.5; i=$((i+1))
    done
    log "WARN: Core/Device 未在 10s 内退出，强制 kill -9"
    for P in $(ps -eo pid,comm | awk '$2=="Core" || $2=="Device" {print $1}'); do
        $SUDO kill -9 "$P" 2>/dev/null
    done
    sleep 1
    if pgrep -x Core >/dev/null 2>&1 || pgrep -x Device >/dev/null 2>&1; then
        die "无法结束 Core/Device（权限不足），$APP_PORT 仍被占用"
    fi
    return 0
}

start_services() {
    if [ "$NTMEGA_WAS_ACTIVE" = "active" ]; then
        log "恢复 ntmega 服务"
        $SUDO systemctl start ntmega >/dev/null 2>&1
        i=0
        while [ $i -lt 20 ]; do
            [ "$(systemctl is-active ntmega 2>/dev/null)" = "active" ] && break
            sleep 0.5; i=$((i+1))
        done
        log "ntmega=$(systemctl is-active ntmega 2>/dev/null)"
        ps -eo pid,user,comm | awk '$3=="Core" || $3=="Device" {print "    "$0}'
        # 健康检查（Core 1888 / Device 1889）
        for U in 1888 1889; do
            if curl -s -m 3 "http://localhost:$U/test" >/dev/null 2>&1; then
                log "  端口 $U OK"
            else
                log "  WARN: 端口 $U 无响应"
            fi
        done
    else
        log "ntmega 升级前未运行，保持不动"
    fi
}

# 无论成功/失败/被信号打断，都恢复服务并清理临时目录
cleanup() {
    start_services
    [ -n "${WORK:-}" ] && [ -d "$WORK" ] && rm -rf "$WORK" 2>/dev/null
}

# 中断处理：关键是要先把 OTA 子进程杀掉，否则它继续占着 ttyS3，
# 恢复服务时 Core 会和它抢串口，导致 ntmega 起来但通讯异常。
OTA_PID=""
on_signal() {
    log "收到中断信号，终止进行中的 OTA 子进程"
    if [ -n "${OTA_PID:-}" ]; then
        kill -TERM "$OTA_PID" 2>/dev/null
        sleep 1
        kill -9 "$OTA_PID" 2>/dev/null
    fi
    pkill -9 -f mcu_ota_upd 2>/dev/null
    sleep 1
    log "OTA 子进程已清理，开始恢复服务"
    exit 130
}

trap 'on_signal' INT TERM
trap 'cleanup' EXIT

stop_services

# 等待串口真正可读（最多 5s）
i=0
while [ $i -lt 10 ]; do
    if "$ROOT/MegaTest" mcu_ota_ver >/dev/null 2>&1; then break; fi
    sleep 0.5; i=$((i+1))
done

# ---------- 1. 部署 MegaTest ----------
if [ -f "$MT_SRC" ]; then
    M_SRC=$(md5sum "$MT_SRC" | awk '{print $1}')
    M_DST=$(md5sum /home/cat/MegaTest 2>/dev/null | awk '{print $1}')
    if [ "$M_SRC" = "$M_DST" ]; then
        log "MegaTest 已是同版本（md5=$M_SRC），跳过部署"
    else
        log "部署 MegaTest -> /home/cat/MegaTest"
        if [ -f /home/cat/MegaTest ]; then
            BAK="/home/cat/MegaTest.bak.$(date +%Y%m%d_%H%M%S)"
            cp -f /home/cat/MegaTest "$BAK" && log "旧版本已备份: $BAK"
        fi
        cp -f "$MT_SRC" /home/cat/MegaTest.new || die "拷贝 MegaTest 失败"
        chmod 755 /home/cat/MegaTest.new
        mv -f /home/cat/MegaTest.new /home/cat/MegaTest || die "替换 MegaTest 失败"
        log "MegaTest md5=$(md5sum /home/cat/MegaTest | awk '{print $1}')"
    fi
fi
MT=/home/cat/MegaTest
[ -x "$MT" ] || die "$MT 不可执行"

# ---------- 2. 查活动槽 ----------
log "查询当前活动槽..."
VER_OUT=$("$MT" mcu_ota_ver 2>&1)
echo "$VER_OUT" | sed 's/^/    /'
ACTIVE=$(echo "$VER_OUT" | grep -o 'App [AB]' | head -1 | awk '{print $2}')
[ -n "$ACTIVE" ] || die "无法解析活动槽（MCU 是否在跑？）"
log "当前活动槽: App $ACTIVE"

if [ "$ACTIVE" = "A" ]; then
    TARGET_OFF=$B_OFF_KB; TARGET_SLOT=B
else
    TARGET_OFF=$A_OFF_KB; TARGET_SLOT=A
fi
log "目标槽: App $TARGET_SLOT (offset ${TARGET_OFF}KB)"

# ---------- 3. 从完整镜像提取目标槽 ----------
[ -f "$FULL_IMG" ] || die "包内缺少完整镜像: $FULL_IMG"
log "完整镜像: $(basename "$FULL_IMG")  $(stat -c %s "$FULL_IMG") B  md5=$(md5sum "$FULL_IMG" | awk '{print $1}')"

rm -rf "$WORK" 2>/dev/null
mkdir -p "$WORK" 2>/dev/null || die "无法创建工作目录 $WORK"
[ -w "$WORK" ] || die "工作目录不可写: $WORK（属主 $(ls -ld "$WORK" | awk '{print $3}')）"
SLOT_BIN="$WORK/app_$TARGET_SLOT.bin"
DD_ERR=$(dd if="$FULL_IMG" of="$SLOT_BIN" bs=1024 skip=$TARGET_OFF count=$SLOT_KB 2>&1) || die "提取槽镜像失败: $DD_ERR"
[ -s "$SLOT_BIN" ] || die "槽镜像为空: $SLOT_BIN"
SLOT_VER=$(dd if="$SLOT_BIN" bs=1 skip=1024 count=4 2>/dev/null | od -An -tx1 | tr -d ' \n')
log "槽镜像: $(stat -c %s "$SLOT_BIN") B  ver(hex@0x400)=$SLOT_VER  md5=$(md5sum "$SLOT_BIN" | awk '{print $1}')"

# ---------- 4. 执行 OTA ----------
log "开始 A/B OTA -> App $TARGET_SLOT"
timeout 240 "$MT" mcu_ota_upd "$APP_PORT" "$SLOT_BIN" > "$WORK/ota.log" 2>&1 &
OTA_PID=$!
wait "$OTA_PID"
RC=$?
OTA_PID=""
sed 's/^/    /' "$WORK/ota.log"
log "mcu_ota_upd 返回 rc=$RC"
[ "$RC" -eq 0 ] || die "OTA 失败，MCU 仍运行在 App $ACTIVE 槽（未切换）"

# ---------- 5. 复查 ----------
sleep 2
log "OTA 后复查:"
"$MT" mcu_ota_ver 2>&1 | sed 's/^/    /'
NEW_ACTIVE=$("$MT" mcu_ota_ver 2>&1 | grep -o 'App [AB]' | head -1 | awk '{print $2}')
if [ "$NEW_ACTIVE" = "$TARGET_SLOT" ]; then
    log "OK: 活动槽已从 App $ACTIVE 切换到 App $TARGET_SLOT"
else
    log "WARN: 活动槽仍为 App ${NEW_ACTIVE:-?}，切换可能未生效"
fi

log "完成，rc=0"
exit 0
