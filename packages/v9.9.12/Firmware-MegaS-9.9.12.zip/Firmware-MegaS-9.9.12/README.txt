MCU A/B 双槽 OTA 测试包 v9.9.12 / MCU-ONLY
=========================================

相对 v9.9.11 的变更:
  + 升级前自动 systemctl stop ntmega 并结束 Core/Device，释放 /dev/ttyS3
  + trap EXIT 保证无论成功、失败还是被 Ctrl-C/信号打断，都会恢复 ntmega
  + 停服务后轮询 mcu_ota_ver 最多 5s，确认串口真的空出来
  + 记录升级前 ntmega 状态，若原本未运行则不会被拉起

内容:
  MegaTest                 上位机（debug 版，含 mcu_ota_ver / mcu_ota_upd）
  megamcu_1.0.0.5.bin      MCU 完整镜像（boot 1.0.0.1 + AppA/AppB 各 1.0.0.5）
  deploy_mcu.sh             停服务 -> 查活动槽 -> 提取另一槽 -> mcu_ota_upd -> 复查 -> 恢复服务
  manifest.json             元信息

布局: boot 0x08000000 | AppA 0x08007000(28KB) | AppB 0x08043000(268KB) | 每槽 240KB
