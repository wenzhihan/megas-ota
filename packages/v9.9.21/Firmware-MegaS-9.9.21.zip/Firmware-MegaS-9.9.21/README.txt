MEGAS 系统文件覆盖式升级包 v9.9.21 / RNDIS 环境部署（含重启）
===============================================================

⚠️ 本包为测试产物（fake: true）。相对 v9.9.17 的唯一变化：
   新增 runUpdate-sys.sh 完整入口，**升级流程包含激活 + 重启系统**。
   MCU 50 轮压测已于 17:45:29 结束（100/100 PASS），设备侧执行已获用户指示。

v9.9.21 升级链路（runUpdate-sys.sh，须 root 或免密 sudo）：
  1. GitHub 拉 Firmware-MegaS-9.9.21.zip + sha256，比对哈希
  2. unzip 到 /tmp/rndis_upgrade/
  3. deploy_sys.sh --apply：备份到 /home/cat/pub/backup_sys_<ts>/，逐文件原子覆盖 + md5 校验
  4. 激活：systemctl daemon-reload / enable mega-vnic.service / nmcli connection reload
  5. deploy_sys.sh --verify 复核落地文件
  6. **setsid 延迟 3s 执行 systemctl reboot**（脱离 SSH 会话，保证重启一定发出）
  7. 状态写 /home/cat/rndis_upgrade_state（BOOT_BEFORE / BACKUP / SHA256 / STATUS / REBOOT）
  8. 上位机轮询设备重新上线，以 boot_id 变化确认重启，再跑验收清单

  加 --no-reboot 可只覆盖不重启（deploy_sys.sh 本身永远不重启）。
  回退：sh deploy_sys.sh <root> --rollback /home/cat/pub/backup_sys_<ts>

一、包结构（系统 tree，覆盖根 = /）
----------------------------------
  Firmware-MegaS-9.9.21/
  ├── etc/
  │   ├── systemd/system/mega-vnic.service
  │   └── NetworkManager/system-connections/mega-vnic-usb0.nmconnection
  ├── home/cat/mega_deploy/
  │   ├── usb-switch.sh       切换引擎（UVC <-> RNDIS）
  │   ├── vnic_lib.sh         公共函数（configfs/UDC/usb0/dnsmasq）
  │   ├── vnic_up.sh          开虚拟网卡 + DHCP
  │   ├── vnic_down.sh        关并恢复 UVC
  │   ├── vnic_boot.sh        开机入口（三级自愈）
  │   ├── vnic_status.sh      状态总览
  │   └── vnic_install.sh     安装器
  ├── deploy_sys.sh           覆盖式升级执行器（默认 DRY-RUN）
  ├── manifest.json           文件清单 / 权限 / 目标路径
  ├── README.txt              本文件
  └── pc-tools/               PC 侧上位机软件（不覆盖到系统）
      ├── mega_deploy.py      CLI 主程序
      ├── mega_web.py         Web 控制台 http://127.0.0.1:8765
      ├── config.json         设备预设
      ├── run_cli.bat / run_gui.bat
      └── README.md

  deploy_sys.sh 只遍历白名单目录（etc/home/usr/opt/var/lib/bin/sbin），
  manifest/README/pc-tools/本脚本不会被写进系统。

二、RNDIS 部署内容汇总（来自既有记忆与 E:\mega\rndis）
------------------------------------------------------
  平台：LubanCat-2IO / RK3568 / Ubuntu 20.04.6 / 内核 4.19.232
  gadget：固定复用 /sys/kernel/config/usb_gadget/g1，UDC=fcc00000.dwc3
  ★ 设计铁律：绝不 mkdir/rmdir gadget 目录。Rockchip 4.19 的 android_usb
    补丁只允许一个 gadget；建第二个会 ENOMEM，且失败清理会触发内核 Oops。
    系统自带 /usr/bin/usbdevice 会建 rockchip/b.1，与 g1 冲突，不可用。
  切换方式：解绑 UDC -> 功能级增删（uvc.0 <-> rndis.0）-> 重新绑 UDC。
    UVC 删除必须清掉全部 7 个符号链接（streaming/header/h/m 等），否则 rmdir
    失败、g1 残留。解绑前若 Windows 仍开着摄像头流，dwc3 可能 not attached，
    需先解绑 gadget 再平台级 unbind/bind 恢复（顺序不能反）。
  VID/PID：0x1d6b / 0x0104（Linux 标准多功能复合设备）。
    原 0x0525/0xa4a2 会被本机 oem16.inf 按硬件 ID 抢绑整机，子接口不出现。
  网络：设备 usb0=192.168.42.1/24，dnsmasq 给 PC 分 192.168.42.100/24；
    NM 专用 manual profile（never-default）防止 DHCP 客户端冲掉静态 IP。
  开机：mega-vnic.service（Type=oneshot, RemainAfterExit=yes,
    After=network.target）；不能用硬 After=ntmega —— 108 上 ntmega 长期
    activating 会把本服务一起挂住。脚本内限时等 g1 + 三级自愈
    （replug -> dwc3 unbind/bind -> 兜底回绑）。
  实测（181）：Windows 枚举 "Remote NDIS based Internet Sharing Device"，
    DHCP 得 192.168.42.100，ping 4/4，SSH 经 192.168.42.1 登录成功；
    两次 ntmega 开关均自动恢复。吞吐 ~170-180 Mbit/s（USB2.0 HS 上限）。
  已知坑：
    1. Ubuntu NM 自动生成 "Wired connection N" DHCP 档冲掉静态 IP → 装 manual profile 并删旧档。
    2. kill -0 对 root 进程 EPERM 误判 → 状态检查改 ps -p。
    3. 切 UVC->RNDIS 后 state=not attached 常见 → replug，仍不行则 dwc3 重载（必须先解绑态）。
    4. 108 缺 20-usb-rndis-network.conf，NM 显示 usb0 unmanaged，但静态 IP 由脚本设，功能不受影响。

三、上位机软件（记忆里提到的那个）
----------------------------------
  E:\demo\mega_deploy\ —— PC 侧轻量部署工具，已随包附在 pc-tools/。
    形态：Python CLI + 本地 Web 控制台（http.server，无 tkinter 依赖）
    传输：paramiko SFTP，带进度 + 逐文件 md5 校验
    功能：deploy（Device/Core/MegaTest）、vnic install/up/down/status、日志
    快速开始：run_gui.bat 打开控制台；run_cli.bat probe --ip <IP>
    载荷：Device/Core/MegaTest 二进制在原工程 payload/ 下（36 MB），
          本包【未包含】—— 那些属于应用升级，不属于 RNDIS 系统环境。
    参考：E:\mega\rndis\README-使用说明.txt（23 KB，含完整排查记录）
          E:\mega\LubanCat 2IO RNDIS切换失败排查与修复说明.txt（9.7 KB）

四、deploy_sys.sh 用法
----------------------
  sh deploy_sys.sh <payload_root>                     # DRY-RUN，仅列出将覆盖的文件
  sh deploy_sys.sh <payload_root> --apply            # 备份 + 原子覆盖 + md5 校验
  sh deploy_sys.sh <payload_root> --verify  <backup> # 校验已落地文件
  sh deploy_sys.sh <payload_root> --rollback <backup># 整包回退（含删除新增文件）

  备份：/home/cat/pub/backup_sys_<时间戳>/，含 files/ 原始副本 + manifest.tsv
        （字段：相对路径 / mode / 原状态 PRESENT|ABSENT / 旧 md5 / 新 md5）。
  权限：*.sh=755，*.service=644，*.nmconnection=600，其它=644。
  原子替换：install -m <mode> src dst.new && mv -f dst.new dst。
  ★ 服务激活（systemctl daemon-reload / enable / start / nmcli reload / vnic up）
    不在本脚本内，需另行执行；MCU 压测期间一律不做。

五、版本关系
------------
  v9.9.16 = MCU A/B 双槽 OTA 包（进度条 + 抗干扰 + 回退）
  v9.9.21 = 本包（系统文件覆盖 / RNDIS 环境）
  两者共用同一仓库与 Firmware-MegaS-<ver>.zip 命名，靠版本号区分，互不覆盖。
