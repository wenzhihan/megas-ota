#!/bin/sh
# 安装后钩子（虚假包，只打印）
echo "[post-install] fake hook, nothing to do"
