FAKE OTA PACKAGE / 虚假升级包
============================

用途: 验证设备能否从 GitHub 仓库拉取升级压缩包, 以及 runUpdate.sh 的
      下载 -> 解压 -> 载荷根目录识别 -> 校验 链路。

内容:
  manifest.json    机型/版本元信息 (fake=true)
  newCore          纯文本占位, 不是可执行固件
  post-install.sh  只打印, 不做任何事
  README.txt       本文件

警告:
  真实的 run_soc_update() 会 kill 进程、把 Core 备份成 Core.bak 并覆盖,
  再 ./Core -v。本包仅用于链路验证, 对应脚本中的实际升级动作已全部注释。
