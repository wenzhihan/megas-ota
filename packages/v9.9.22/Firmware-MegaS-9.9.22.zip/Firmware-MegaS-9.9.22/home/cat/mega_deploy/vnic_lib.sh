#!/bin/sh
# ============================================================
# vnic_lib.sh — 公共函数（被 vnic_up/down/boot/status 引用）
#
# 关键约束（来自 RK3568 实机经验，勿破坏）:
#   1. Rockchip 4.19 内核只允许存在一个 gadget 目录：始终复用 g1，
#      绝不 mkdir 第二个、也绝不 rmdir g1（会触发内核 Oops）。
#   2. configfs 符号链接的相对 target 按【进程 cwd】解析，
#      ln 前必须 cd 到 gadget 目录。
#   3. usb0 是否存在用 ip link 判断（sysfs /sys/class/net/usb0 重绑后会悬空）。
# ============================================================

GADGET=/sys/kernel/config/usb_gadget/g1
VNIC_DIR=$(cd "$(dirname "$0")" && pwd)

ensure_configfs() {
    mountpoint -q /sys/kernel/config 2>/dev/null && return 0
    mount -t configfs none /sys/kernel/config 2>/dev/null
    [ -d /sys/kernel/config/usb_gadget ]
}

udc_name() { ls /sys/class/udc 2>/dev/null | head -1; }

udc_state() { cat "/sys/class/udc/$(udc_name)/state" 2>/dev/null; }

# dwc3 重载后 UDC 节点需要时间重新注册，写 bind 前必须等它出现
wait_udc_node() {
    U="$1"; i=0
    while [ ! -e "/sys/class/udc/$U" ] && [ $i -lt 50 ]; do sleep 0.2; i=$((i+1)); done
    [ -e "/sys/class/udc/$U" ]
}

# 结束态兜底：g1 必须绑着 UDC（空 = 连 gadget 都没有，比 not attached 更糟）
ensure_udc_bound() {
    U="$1"
    [ -n "$U" ] || return 1
    if [ -s "$GADGET/UDC" ]; then return 0; fi
    wait_udc_node "$U" || return 1
    echo "$U" > "$GADGET/UDC" 2>/dev/null
    sleep 1
    [ -s "$GADGET/UDC" ]
}

usb0_exists() { ip link show usb0 >/dev/null 2>&1; }

# dnsmasq 是否存活（pid 文件 + ps 校验；root 进程用 kill -0 会 EPERM 误判）
dnsmasq_alive() {
    P=$(cat /var/run/dnsmasq-usb0.pid 2>/dev/null)
    [ -n "$P" ] || return 1
    ps -p "$P" -o comm= 2>/dev/null | grep -q dnsmasq
}

# g1 不存在时建一个最小骨架（UVC/RNDIS 都由后续 function 增删完成）
ensure_g1() {
    ensure_configfs || return 1
    [ -d "$GADGET" ] && return 0
    cd /sys/kernel/config/usb_gadget || return 1
    mkdir g1 2>/dev/null || return 1
    cd g1 || return 1
    echo 0x1d6b > idVendor
    echo 0x0104 > idProduct
    echo 0x0100 > bcdDevice
    echo 0x0200 > bcdUSB
    mkdir -p strings/0x409
    echo "Mega"              > strings/0x409/manufacturer
    echo "Mega Virtual NIC"  > strings/0x409/product
    echo "MEGAVNIC"          > strings/0x409/serialnumber
    mkdir -p configs/c.1/strings/0x409
    echo "RNDIS"             > configs/c.1/strings/0x409/configuration
    echo 250                 > configs/c.1/MaxPower
    return 0
}

# 确保 usb0 有目标地址（幂等）
ensure_usb0_ip() {
    IP="$1"          # 形如 192.168.42.1/24
    usb0_exists || return 1
    ip link set usb0 up 2>/dev/null
    # 已有同地址则跳过，避免重复 add 报 File exists
    if ip -o -4 addr show usb0 2>/dev/null | grep -q "inet ${IP%/*}/"; then
        return 0
    fi
    ip addr flush dev usb0 2>/dev/null
    ip addr add "$IP" dev usb0 2>/dev/null
}
