#!/bin/sh
# ============================================================
# vnic_up.sh — 开启设备侧虚拟网卡（USB RNDIS）
#
# 用法: sudo sh vnic_up.sh [IP/CIDR] [DHCP给PC的地址]
#   sudo sh vnic_up.sh 192.168.42.1/24 192.168.42.100
#
# 行为:
#   - g1 不存在 -> 先建最小 gadget 骨架
#   - g1 存在（产品 UVC）-> 复用 g1，功能级切换为 rndis（不删 gadget）
#   - 配 usb0 固定 IP + 起 dnsmasq（仅 DHCP），PC 网卡自动拿 192.168.42.100
#
# 输出标记: VNIC_OK <iface> <cidr> rndis / VNIC_FAIL <reason>
# ============================================================
set -u
DIR=$(cd "$(dirname "$0")" && pwd)
. "$DIR/vnic_lib.sh"

CIDR="${1:-${VNIC_IP:-192.168.42.1/24}}"
DHCP_IP="${2:-${VNIC_DHCP_IP:-192.168.42.100}}"
PLAIN_IP="${CIDR%/*}"

[ "$(id -u)" = "0" ] || { echo "VNIC_FAIL need root"; exit 1; }

ensure_g1 || { echo "VNIC_FAIL create gadget g1 failed"; exit 1; }
[ -n "$(udc_name)" ] || { echo "VNIC_FAIL no UDC"; exit 1; }

echo "[vnic] switch g1 -> rndis (ip=$PLAIN_IP, dhcp=$DHCP_IP)"
RNDIS_IP="$PLAIN_IP" DHCP_HOST_IP="$DHCP_IP" SWITCH_YES=1 \
    sh "$DIR/usb-switch.sh" rndis
RC=$?

# usb-switch 内部已配过 IP/DHCP，这里做兜底与最终校验
ensure_usb0_ip "$CIDR" || { echo "VNIC_FAIL usb0 not present"; exit 1; }

# DHCP 兜底重试：开机瞬间 usb0 可能尚未在 netns 注册，dnsmasq 会报
# "unknown interface usb0"（实测 2026-11-12），等 up 后重试即可。
if ! dnsmasq_alive; then
    n=0
    while [ $n -lt 5 ]; do
        n=$((n+1))
        sleep 1
        ensure_usb0_ip "$CIDR"
        sh "$DIR/usb-switch.sh" dhcp start >/dev/null 2>&1
        dnsmasq_alive && { echo "[vnic] dhcp started after retry #$n"; break; }
    done
fi

STATE=$(udc_state)
# 收尾：若切换后 g1 没有绑定 UDC（dwc3 重载/UVC 删除后偶发），补绑一次
if [ ! -s "$GADGET/UDC" ]; then
    ensure_udc_bound "$(udc_name)" && echo "[vnic] UDC 已补绑 $(cat "$GADGET/UDC" 2>/dev/null)"
    STATE=$(udc_state)
fi
CARRIER=$(ip link show usb0 2>/dev/null | grep -c LOWER_UP)
echo "[vnic] udc_state=$STATE carrier=$CARRIER rc=$RC"
ip -br a show usb0

case "$STATE" in
    configured) echo "VNIC_OK usb0 $CIDR rndis" ;;
    *)          echo "VNIC_OK usb0 $CIDR rndis (WARN: udc_state=$STATE, 主机可能未连接/半枚举)"
                echo "          可在设备上执行: sh $DIR/usb-switch.sh replug" ;;
esac
exit 0
