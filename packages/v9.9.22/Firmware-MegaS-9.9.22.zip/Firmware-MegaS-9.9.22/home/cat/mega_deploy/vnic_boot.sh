#!/bin/sh
# ============================================================
# vnic_boot.sh — 开机自动启用虚拟网卡（由 mega-vnic.service 调用）
#
# 流程:
#   1. 等 ntmega/runGadget 建好 g1（最多 30s）；没有就自建骨架
#   2. 功能级切换 g1 -> rndis，配 usb0 固定 IP + dnsmasq
#   3. 三级自愈：UDC 摘挂 -> dwc3 平台驱动重载（各 3 轮）
#
# 日志: /home/cat/pub/log/mega-vnic.log
# 注意: 始终 exit 0，避免 systemd 因主机未接线而反复重启服务。
# ============================================================
set -u
DIR=$(cd "$(dirname "$0")" && pwd)
. "$DIR/vnic_lib.sh"

LOG_DIR=/home/cat/pub/log
LOG=$LOG_DIR/mega-vnic.log
mkdir -p "$LOG_DIR" 2>/dev/null
exec >> "$LOG" 2>&1

CIDR="${VNIC_IP:-192.168.42.1/24}"
DHCP_IP="${VNIC_DHCP_IP:-192.168.42.100}"

echo "===== [mega-vnic] boot $(date '+%F %T') ====="

# 1. 等 g1 出现（ntmega 正常时它会先建 UVC），限时 30s；没有则自建
i=0
while [ ! -d "$GADGET" ] && [ $i -lt 30 ]; do sleep 1; i=$((i+1)); done
echo "[mega-vnic] wait g1: ${i}s, exists=$([ -d "$GADGET" ] && echo yes || echo no)"
ensure_g1 || { echo "[mega-vnic] FAIL ensure_g1"; exit 0; }

# 2. 切换 + 配 IP
sh "$DIR/vnic_up.sh" "$CIDR" "$DHCP_IP"
echo "[mega-vnic] after up: state=$(udc_state)"

# 3. 三级自愈
UDC=$(udc_name)

# 收尾校正：ntmega 若在本服务之后才建 gadget(UVC)，把 rndis 再切回来一次
post_check() {
    sleep 5
    if [ -d "$GADGET/functions/uvc.0" ]; then
        echo "[mega-vnic] 检测到 uvc.0 重新出现（ntmega 后建 gadget），再次切换"
        sh "$DIR/vnic_up.sh" "$CIDR" "$DHCP_IP" >/dev/null 2>&1
        sleep 2
    fi
}

for n in 1 2 3; do
    sleep 3
    S=$(udc_state)
    echo "[mega-vnic] check#$n state=$S"
    [ "$S" = "configured" ] && { echo "[mega-vnic] OK configured"; post_check; exit 0; }

    echo none > "$GADGET/UDC" 2>/dev/null; sleep 1
    echo "$UDC" > "$GADGET/UDC" 2>/dev/null; sleep 3
    S=$(udc_state); echo "[mega-vnic] replug#$n state=$S"
    [ "$S" = "configured" ] && { echo "[mega-vnic] OK configured (replug)"; post_check; exit 0; }

    echo none > "$GADGET/UDC" 2>/dev/null
    echo "$UDC" > /sys/bus/platform/drivers/dwc3/unbind 2>/dev/null; sleep 1
    echo "$UDC" > /sys/bus/platform/drivers/dwc3/bind  2>/dev/null
    # dwc3 重载后 UDC 节点注册需要时间，等不到就跳过本轮绑定
    if wait_udc_node "$UDC"; then
        sleep 1
        echo "$UDC" > "$GADGET/UDC" 2>/dev/null; sleep 3
    else
        echo "[mega-vnic] recover#$n: UDC 节点未重新注册"
    fi
    S=$(udc_state); echo "[mega-vnic] recover#$n state=$S"
    [ "$S" = "configured" ] && { echo "[mega-vnic] OK configured (dwc3 rebind)"; post_check; exit 0; }
done

# 收尾：任何情况下都要保证 g1 绑着 UDC（空绑定 = gadget 完全不存在）
ensure_udc_bound "$UDC" && echo "[mega-vnic] UDC 已回绑 $(cat "$GADGET/UDC" 2>/dev/null)" \
                       || echo "[mega-vnic] WARN UDC 回绑失败（可重启或手动 echo $UDC > g1/UDC）"

echo "[mega-vnic] WARN 未完成枚举（state=$(udc_state)）：多为主机未接线/未开端口，"
echo "[mega-vnic]      接线后可手动: sh $DIR/usb-switch.sh replug"
exit 0
