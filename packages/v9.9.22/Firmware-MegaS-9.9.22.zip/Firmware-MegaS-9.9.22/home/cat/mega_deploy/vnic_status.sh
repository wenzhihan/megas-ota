#!/bin/sh
# ============================================================
# vnic_status.sh — 虚拟网卡状态总览（只读）
# 用法: sh vnic_status.sh
# ============================================================
DIR=$(cd "$(dirname "$0")" && pwd)
. "$DIR/vnic_lib.sh"

echo "== gadget =="
echo "  dir       : $(ls /sys/kernel/config/usb_gadget/ 2>/dev/null)"
echo "  functions : $(ls $GADGET/functions/ 2>/dev/null | tr '\n' ' ')"
echo "  configs   : $(ls $GADGET/configs/c.1/ 2>/dev/null | tr '\n' ' ')"
echo "  VID:PID   : $(cat $GADGET/idVendor 2>/dev/null):$(cat $GADGET/idProduct 2>/dev/null)"
echo "== UDC =="
echo "  controller: $(cat $GADGET/UDC 2>/dev/null)"
echo "  state     : $(udc_state)"
echo "  speed     : $(cat /sys/class/udc/$(udc_name)/current_speed 2>/dev/null)"
echo "== usb0 =="
if usb0_exists; then
    ip -br a show usb0
    ip link show usb0 | grep -q LOWER_UP && echo "  carrier   : UP(PC 网卡在线)" || echo "  carrier   : DOWN(PC 侧未连上)"
else
    echo "  (不存在，当前非 RNDIS 模式)"
fi
echo "== DHCP =="
if dnsmasq_alive; then
    echo "  dnsmasq   : running pid $(cat /var/run/dnsmasq-usb0.pid 2>/dev/null)"
    [ -f /tmp/dnsmasq-usb0.leases ] && sed -n '1,5p' /tmp/dnsmasq-usb0.leases
else
    echo "  dnsmasq   : not running"
fi
echo "== NetworkManager =="
echo "  usb0      : $(nmcli -t -f GENERAL.STATE,GENERAL.CONNECTION dev show usb0 2>/dev/null | head -2 | tr '\n' ' ')"
echo "== service =="
echo "  enabled   : $(systemctl is-enabled mega-vnic 2>/dev/null)"
echo "  active    : $(systemctl is-active mega-vnic 2>/dev/null)"
echo "== 最近日志 =="
tail -n 6 /home/cat/pub/log/mega-vnic.log 2>/dev/null || echo "  (无)"
