#!/bin/sh
# ============================================================
# vnic_install.sh — 把虚拟网卡运行环境装到设备并设为开机自启
#
# 前提: 本脚本与 usb-switch.sh / vnic_lib.sh / vnic_up.sh /
#       vnic_down.sh / vnic_boot.sh / vnic_status.sh /
#       mega-vnic.service 同在一个 staging 目录。
#
# 用法: sudo sh vnic_install.sh [--start] [--uninstall]
#   --start      安装后立即启动一次
#   --uninstall  停服务、禁用、删 unit（保留脚本与已有网卡状态）
#
# 输出标记: INSTALL_OK / UNINSTALL_OK / INSTALL_FAIL <reason>
# ============================================================
set -u
DIR=$(cd "$(dirname "$0")" && pwd)
DEST=/home/cat/mega_deploy
UNIT=mega-vnic.service
UNIT_PATH=/etc/systemd/system/$UNIT
FILES="usb-switch.sh vnic_lib.sh vnic_up.sh vnic_down.sh vnic_boot.sh vnic_status.sh"

[ "$(id -u)" = "0" ] || { echo "INSTALL_FAIL need root"; exit 1; }

uninstall() {
    systemctl stop $UNIT 2>/dev/null
    systemctl disable $UNIT 2>/dev/null
    rm -f "$UNIT_PATH"
    systemctl daemon-reload
    systemctl reset-failed $UNIT 2>/dev/null
    echo "UNINSTALL_OK (脚本保留在 $DEST)"
}

if [ "${1:-}" = "--uninstall" ]; then uninstall; exit 0; fi

mkdir -p "$DEST" || { echo "INSTALL_FAIL mkdir $DEST"; exit 1; }

for f in $FILES; do
    [ -f "$DIR/$f" ] || { echo "INSTALL_FAIL missing $f"; exit 1; }
    install -m 755 "$DIR/$f" "$DEST/$f" || { echo "INSTALL_FAIL copy $f"; exit 1; }
done

[ -f "$DIR/$UNIT" ] || { echo "INSTALL_FAIL missing $UNIT"; exit 1; }
install -m 644 "$DIR/$UNIT" "$UNIT_PATH" || { echo "INSTALL_FAIL copy unit"; exit 1; }

systemctl daemon-reload
systemctl enable $UNIT >/dev/null 2>&1 || { echo "INSTALL_FAIL enable"; exit 1; }

# ---------- NetworkManager: usb0 固定静态地址，避免被 DHCP 客户端冲掉 ----------
# 产品自带 /etc/NetworkManager/conf.d/20-usb-rndis-network.conf 让 NM 管理 usb0，
# NM 会自动生成 "Wired connection N" 走 DHCP 客户端，开机后 flush 掉静态 IP。
# 这里装一个专用 profile（method=manual）替代它，保证 IP 由我们决定。
VNIC_CIDR="${VNIC_IP:-192.168.42.1/24}"
NM_CON=/etc/NetworkManager/system-connections/mega-vnic-usb0.nmconnection
if [ -d /etc/NetworkManager ]; then
    cat > "$NM_CON" <<EOF
[connection]
id=mega-vnic-usb0
type=ethernet
interface-name=usb0
autoconnect=true
autoconnect-priority=100

[ethernet]

[ipv4]
method=manual
address1=$VNIC_CIDR
never-default=true

[ipv6]
method=ignore
EOF
    chmod 600 "$NM_CON"
    # 删掉 NM 自动生成的 usb0 DHCP 档，避免抢连
    for u in $(nmcli -t -f UUID,NAME,DEVICE con show 2>/dev/null | awk -F: '$3=="usb0" && $2!="mega-vnic-usb0"{print $1}'); do
        nmcli con delete "$u" >/dev/null 2>&1
    done
    nmcli connection reload >/dev/null 2>&1
    echo "NM profile: $NM_CON (static $VNIC_CIDR)"
fi

echo "已安装到 $DEST, 单元 $UNIT_PATH"
echo "  enabled : $(systemctl is-enabled $UNIT 2>/dev/null)"

if [ "${1:-}" = "--start" ]; then
    systemctl start $UNIT
    echo "  active  : $(systemctl is-active $UNIT 2>/dev/null)"
fi

echo "INSTALL_OK $DEST"
