#!/bin/sh
# =====================================================================
# LubanCat-2IO (RK3568) UVC(虚拟摄像头) <-> RNDIS(USB 网卡) 双向切换
# 归档: E:\mega\rndis\usb-switch.sh   (2026-09-02 v4 稳定版, 六验通过)
#
# 用法(在板子系统终端执行, 需 root):
#   sudo ./usb-switch.sh rndis    切到 RNDIS 网络模式(USB 网卡)
#   sudo ./usb-switch.sh uvc      切到 UVC 虚拟摄像头模式(1600x1200)
#   sudo ./usb-switch.sh toggle   来回切换: 自动切到当前相反的模式
#   sudo ./usb-switch.sh status   查看当前 gadget / 网络 / DHCP 状态
#   sudo ./usb-switch.sh replug   摘挂 UDC 强制主机重新枚举(见下)
#   sudo ./usb-switch.sh uvc-app {start|stop|status}
#                                 仅停/启 run.sh 生态里的 uvc-gadget 出流应用
#                                 (不碰 gadget, 不碰 Core/run.sh)
#   sudo ./usb-switch.sh dhcp {start|stop}
#                                 单独启停 usb0 的 dnsmasq DHCP
#
# 设计原则(重要, 勿破坏):
#   1. 始终复用 /sys/kernel/config/usb_gadget/g1, 绝不 mkdir/rmdir gadget 目录。
#      Rockchip 4.19 内核 CONFIG_USB_CONFIGFS_UEVENT(android_usb) 补丁只允许
#      存在一个 gadget 目录: 已有 g1 时再建第二个会报 "Cannot allocate memory",
#      且失败后清理会触发内核 Oops(configfs 锁死, 只能重启恢复)。
#      —— 系统自带 /usr/bin/usbdevice(建 rockchip/b.1)与 g1 冲突, 不可用。
#   2. 切换 = 解绑 UDC -> 功能(function)级增删 -> 重新绑 UDC。
#   3. UVC 功能删除必须清掉全部符号链接(原 uvc-gadget.sh 漏删
#      streaming/header/h/m 导致 rmdir 失败、g1 残留, 是历史故障根因)。
#   4. 解绑时 UVC/RNDIS 若有活动传输, dwc3 可能卡死(轻则 state=not
#      attached + failed to enable ep0out, 重则系统级冻结), 只能断电或
#      rec-dwc3-recovery.sh 恢复 —— 切换前必须先让主机侧会话停掉。
#   5. 主机"半枚举"(state=default, 线在但 Windows 不完成 config)不是
#      卡死; 4.19 的 soft_connect 节点未实现(echo 0/1 报 I/O error),
#      有效自愈 = UDC 摘除再重挂一次(replug_udc, 六验实测一次即恢复)。
#
# 版本记录:
#   2026-08-31  v1 实机验证 UVC->RNDIS->UVC 双向切换成功。
#   2026-09-02  增强: toggle/root 检查/usb0 IP 清理/uvc.0 残留检测。
#   2026-09-02  v3: 幂等自愈 + confirm_unbind + dhcp 666 预建 +
#               usb0 判断改 ip link(RK3568 sysfs 链接悬空怪癖) + dhcp 子命令。
#   2026-09-02  v4(稳定版): + replug_udc 强制重枚举 + 绑后 wait_configured
#               自动自愈 + dnsmasq 存活校验 + 切 UVC 前先 down usb0
#               (15:41 活跃 RNDIS unbind 冻结教训)。六验 = 本机
#               DESKTOP-BN8MK2R, Ethernet 5 拿 .100, 双向 ping 0%。
# =====================================================================

GADGET=/sys/kernel/config/usb_gadget/g1
UDC=fcc00000.dwc3
UVC_PID=0x636d
UVC_VID=0x0c45
# 默认改 1d6b:0104: 本机 oem16.inf 会按 0525:a4a2 硬件ID 抢绑整机
RNDIS_VID=${RNDIS_VID:-0x1d6b}
RNDIS_PID=${RNDIS_PID:-0x0104}
# RNDIS 模式设备侧 IP(按需修改; Windows 主机侧配同网段静态 IP 即可互通)
# 2026-09-02: 默认改为 192.168.42.1 (Windows 侧 192.168.42.100/24)
RNDIS_IP=${RNDIS_IP:-192.168.42.1}
# RNDIS 模式: usb0 上启用 DHCP server(dnsmasq, 仅 DHCP 不做 DNS), 主机自动拿此 IP
DHCP_HOST_IP=${DHCP_HOST_IP:-192.168.42.100}
DHCP_CONF=/tmp/usb0-dnsmasq.conf
DHCP_PID=/var/run/dnsmasq-usb0.pid
DHCP_LOG=/tmp/dnsmasq-usb0.log
DHCP_LEASE=/tmp/dnsmasq-usb0.leases
# 切回 UVC 后是否自动拉起板端出流应用 uvc-gadget(0=只提示, 1=自动 start)
# 2026-09-02: 默认改为 1 —— 出流应用独立于 Core/run.sh, 拉起它即"恢复原环境"。
AUTO_UVC_APP=${AUTO_UVC_APP:-1}

# ---- run.sh 生态(勿动 Core/webCamera/Device/webssh/run.sh 本身) ----
# 板端 run.sh 以二进制 ./uvc-gadget 启动虚拟摄像头出流应用:
#   start_service "uvc-gadget" "./uvc-gadget" log/uvc-gadget.log /tmp/.../uvc-gadget.pid
# 该应用打开 dwc3 的 UVC gadget 视频节点(如 /dev/video11), 从 jpg/frame.jpg 出流。
# run.sh 的 monitor_all_services 守护名单不含 uvc-gadget 且整段被注释,
# 因此 stop 它不会被 run.sh 自动拉起 —— 切 rndis 只需精确停此应用。
PUB_DIR=/home/cat/pub
UVC_APP_LOG=${PUB_DIR}/log/uvc-gadget.log
UVC_APP_PID=/tmp/megalasercore-pids/uvc-gadget.pid
UVC_APP_NAME=uvc-gadget        # 进程名(comm), 兜底 pkill -x 用
PID_DIR=/tmp/megalasercore-pids

# ---- 基础操作 ------------------------------------------------------

require_root() {
    [ "$(id -u)" = 0 ] || { echo "请用 sudo 运行: sudo $0 $1"; exit 1; }
}

# 解绑前确认: 主机侧活跃的 UVC/RNDIS 会话下解绑会触发 dwc3 卡死
# (2026-09-02 两次实测教训, 只能断电重启)。交互终端弹 y/N;
# 非交互运行或设 SWITCH_YES=1 时直接放行(供脚本/远程自动化)。
confirm_unbind() {
    [ "$SWITCH_YES" = "1" ] && return 0
    if [ -t 0 ]; then
        echo ""
        echo "[warn] 即将解绑 USB gadget (UDC=none)。"
        echo "       若 Windows 主机此刻正打开 UVC 摄像头画面 / RNDIS 网卡在传数据,"
        echo "       活跃传输会触发 dwc3 卡死(只能断电重启)。"
        echo "       请先在主机侧关闭摄像头或断开 RNDIS 网卡, 再继续。"
        printf "确认继续? [y/N] "
        read ans
        case "$ans" in
            y|Y) return 0 ;;
            *)   echo "已取消。"; exit 1 ;;
        esac
    fi
}

usage() {
    echo "用法: sudo $0 {rndis|uvc|toggle|status|uvc-app|dhcp} ..."
    echo "  rndis   切到 RNDIS 网络模式(设备 IP $RNDIS_IP, 内置 DHCP 主机自动拿 $DHCP_HOST_IP)"
    echo "          切换前只精确停止 uvc-gadget 出流应用, 不影响 Core/run.sh 等"
    echo "  uvc     切到 UVC 虚拟摄像头模式(1600x1200 MJPEG), AUTO_UVC_APP=$AUTO_UVC_APP 时自动拉起出流应用"
    echo "  toggle  来回切换: 自动切到当前相反的模式"
    echo "  status  查看当前 gadget / 网络 / DHCP / uvc-gadget 应用状态"
    echo "  replug  摘挂 UDC 强制主机重新枚举(state=default 半枚举时用; configured 态会拒绝)"
    echo "  uvc-app start|stop|status   单独启停 uvc-gadget 出流应用(不碰 gadget 与 Core/run.sh)"
    echo "  dhcp    start|stop           单独启停 usb0 的 dnsmasq DHCP(供恢复后补起)"
    echo "  提示: 交互终端会先确认解绑; 脚本/自动化可加 SWITCH_YES=1 跳过确认"
    exit 1
}

unbind_udc() {
    echo none > $GADGET/UDC 2>/dev/null
    sleep 1
}

# dwc3 平台驱动重载(卡死恢复, 2026-09-02 二次实机验证有效)。
# 关键: 必须【先解绑 gadget(g1/UDC=none)】再平台级 unbind/bind, 并确认
# /sys/class/udc/fcc00000.dwc3 重新注册后才重绑。若在 gadget 仍绑定/非
# 干净状态下直接 rebind, UDC 节点不恢复(failed to start g1: -2), 只能重启
# —— 这是 09-02 上午的教训; 正确顺序 09-02 下午恢复成功(state=configured)。
# 默认不自动执行(bind_udc 只提示), 设 FORCE_RECOVER=1 或单独跑
# rec-dwc3-recovery.sh 应急。
recover_dwc3() {
    echo "[recover] dwc3 wedged, reloading platform driver (正确顺序)..."
    echo none > $GADGET/UDC 2>/dev/null
    sleep 1
    echo $UDC > /sys/bus/platform/drivers/dwc3/unbind 2>/dev/null
    sleep 3
    echo $UDC > /sys/bus/platform/drivers/dwc3/bind
    sleep 4
    [ -d /sys/class/udc/$UDC ] || { echo "[recover] FATAL: UDC 节点未恢复, 请重启板子"; exit 9; }
    echo $UDC > $GADGET/UDC
    sleep 3
}

bind_udc() {
    echo $UDC > $GADGET/UDC
    sleep 2
    STATE=$(cat /sys/class/udc/$UDC/state 2>/dev/null)
    echo "[bind] UDC state: $STATE"
    if [ "$STATE" != "configured" ] && [ "$STATE" != "attached" ]; then
        if [ "$FORCE_RECOVER" = "1" ]; then
            echo "[bind] FORCE_RECOVER=1, 尝试 dwc3 平台驱动重载..."
            recover_dwc3
            STATE=$(cat /sys/class/udc/$UDC/state 2>/dev/null)
            echo "[bind] recover 后 UDC state: $STATE"
        else
            echo "[bind] 提示: state=$STATE (未完成主机枚举)"
            echo "      板端自愈: sudo $0 replug  (摘挂 UDC 强制主机重新枚举)"
            echo "      请确认 OTG 口 USB 线已接主机; 仍不行可在 Windows 设备管理器"
            echo "      禁用再启用该 USB 设备, 或拔插 USB 线 / 换数据口。"
            echo "      若属 dwc3 卡死(state=not attached 且 extcon USB=1、"
            echo "      dmesg 报 failed to enable ep0out), 应急可执行:"
            echo "      sudo ./rec-dwc3-recovery.sh  (勿在 gadget 绑定态直接 rebind)"
        fi
    fi
}

# ---- 枚举自愈(state=default 半枚举 / 主机不完成 config) -----------

udc_state() { cat /sys/class/udc/$UDC/state 2>/dev/null; }

# 摘挂 UDC 一次(gadget 级, 不动 dwc3 平台驱动), 强制主机重新走完整枚举。
# 适用: state 停在 default(主机在线、发过 bus reset, 但不走到 config)。
# 2026-09-02 六验: 该态下仅 UDC 重挂一次, dmesg 即完整走
# device reset -> CONNECTED -> high-speed config #1 -> CONFIGURED。
# 注意: 4.19 dwc3 的 soft_connect 节点未实现(写入报 I/O error), 别依赖它。
# 安全约束: state=configured(主机会话活跃)时拒绝执行 —— 活跃传输下摘挂
# 会重演 dwc3 卡死(教训 09-02 15:41 / 16:35)。
replug_udc() {
    local st
    st=$(udc_state)
    if [ "$st" = "configured" ]; then
        echo "[replug] state=configured(主机会话活跃), 拒绝摘挂以免卡死 dwc3。"
        echo "        如需强制重枚举: Windows 设备管理器禁用再启用该设备, 或拔插 OTG 线。"
        return 1
    fi
    echo "[replug] UDC 摘除再重挂, 强制主机重新枚举 (当前 state=$st)..."
    echo none > $GADGET/UDC 2>/dev/null
    sleep 1
    echo $UDC > $GADGET/UDC
    sleep 4
    st=$(udc_state)
    echo "[replug] 重挂后 state=$st  speed=$(cat /sys/class/udc/$UDC/current_speed 2>/dev/null)"
    [ "$st" = "configured" ] && return 0
    echo "[replug] 仍未 configured。请检查: OTG 线是否插在本机数据口 / 线材是否仅充电线;"
    echo "        或 Windows 设备管理器对该设备(带感叹号)手动指定 Microsoft ->"
    echo "        'Remote NDIS Compatible Device'(netrndis.inf)。"
    return 1
}

# bind 后等主机枚举; ~10s 未 configured 自动 replug 一次再验。
wait_configured() {
    local i st
    i=0
    while [ $i -lt 5 ]; do
        st=$(udc_state)
        [ "$st" = "configured" ] && { echo "[enum] state=configured (主机完成枚举)"; return 0; }
        i=$((i+1))
        sleep 2
    done
    echo "[enum] 绑定后 10s 仍未 configured (state=$st), 自动摘挂 UDC 强制重枚举..."
    if replug_udc; then return 0; fi
    st=$(udc_state)
    echo "[enum] 最终 state=$st"
    return 1
}

# ---- DHCP server(usb0, RNDIS 模式专用) -----------------------------

# 停 DHCP: 切到 UVC 前必须停(usb0 会消失, dnsmasq 绑死该接口会报错)
dhcp_stop() {
    [ -f $DHCP_PID ] && kill $(cat $DHCP_PID) 2>/dev/null
    # 兜底: 匹配 dnsmasq 的 cmdline("-C /tmp/usb0-dnsmasq.conf")。
    # 勿用含脚本自身命令串的 pattern, 以免 SSH/包装 shell 自匹配误杀。
    pkill -f 'usb0-dnsmasq.conf' 2>/dev/null
    sleep 1
    echo "[dhcp] stopped"
}

# usb0 存在性判断: 必须用 ip link(netlink)。RK3568 dwc3 重绑后
# /sys/class/net/usb0 符号链接会悬空(-d 判 False, 2026-09-02 实测), 但
# 网卡真实存在且可用, 仅 sysfs 节点缺失。
usb0_exists() { ip link show usb0 >/dev/null 2>&1; }

# 起 DHCP: 单地址池, 保证 RNDIS 主机稳定拿到 $DHCP_HOST_IP
dhcp_start() {
    dhcp_stop
    rm -f $DHCP_PID $DHCP_LOG $DHCP_LEASE
    # 预建空日志/租约并放开权限: dnsmasq 启动后会降权到 nobody, 若不预建
    # 666 文件, 二次启动写 log-facility 会 Permission denied(2026-09-02 实测)。
    touch $DHCP_LOG $DHCP_LEASE 2>/dev/null
    chmod 666 $DHCP_LOG $DHCP_LEASE 2>/dev/null
    cat > $DHCP_CONF <<EOF
interface=usb0
bind-interfaces
dhcp-range=$DHCP_HOST_IP,$DHCP_HOST_IP,255.255.255.0,1h
dhcp-option=3,$RNDIS_IP
port=0
no-resolv
no-hosts
pid-file=$DHCP_PID
dhcp-leasefile=$DHCP_LEASE
log-facility=$DHCP_LOG
EOF
    # usb0 不存在(如 dwc3 卡死未恢复/未枚举)时 dnsmasq 绑定会失败, 提前拦
    if ! usb0_exists; then
        echo "[dhcp] WARN: usb0 不存在, 跳过 DHCP(先确认 RNDIS state=configured / 恢复 dwc3)"
        return 1
    fi
    if dnsmasq -C $DHCP_CONF; then
        sleep 1
        if [ -f $DHCP_PID ] && kill -0 $(cat $DHCP_PID 2>/dev/null) 2>/dev/null; then
            echo "[dhcp] started on usb0 (pid $(cat $DHCP_PID); Windows 自动获取 $DHCP_HOST_IP, 网关 $RNDIS_IP)"
        else
            echo "[dhcp] WARN: dnsmasq 启动后进程未存活, 日志尾部:"
            tail -n 5 $DHCP_LOG 2>/dev/null
        fi
    else
        echo "[dhcp] WARN: dnsmasq 启动失败; 手动排查: sudo dnsmasq --test -C $DHCP_CONF"
    fi
}

# ---- UVC 出流应用(用户态进程, 属 run.sh 生态) ---------------------
# 原则: 只针对 uvc-gadget 这一个应用做精确 stop/start, 绝不影响
# Core/webCamera/Device/webssh/run.sh, 也不碰 configfs gadget 结构。

uvc_app_alive() {
    local p=""
    [ -f "$UVC_APP_PID" ] || return 1
    p=$(cat "$UVC_APP_PID" 2>/dev/null)
    [ -n "$p" ] || return 1
    kill -0 "$p" 2>/dev/null || return 1
    grep -q "$UVC_APP_NAME" "/proc/$p/cmdline" 2>/dev/null || return 1
    return 0
}

# 精确停掉出流应用: 优先用 pid 文件(先校验 cmdline 确属 uvc-gadget, 防
# pid 复用误杀), 兜底 pkill -x 按进程名精确匹配 —— 不用 pkill -f 模糊
# 匹配, 避免误伤 run.sh/SSH 包装进程。
stop_uvc_app() {
    local p=""
    if uvc_app_alive; then
        p=$(cat "$UVC_APP_PID" 2>/dev/null)
        echo "[uvc-app] stopping $UVC_APP_NAME (pid $p)..."
        kill "$p" 2>/dev/null
        sleep 1
        if kill -0 "$p" 2>/dev/null; then
            sleep 2
            kill -0 "$p" 2>/dev/null && { echo "[uvc-app] 未响应 SIGTERM, 升级 SIGKILL"; kill -9 "$p" 2>/dev/null; }
        fi
        rm -f "$UVC_APP_PID"
        echo "[uvc-app] stopped (pid $p)"
        return 0
    fi
    # pid 文件可能残留死 pid, 清掉后按名字兜底
    rm -f "$UVC_APP_PID"
    if pkill -x "$UVC_APP_NAME" 2>/dev/null; then
        echo "[uvc-app] stopped (pkill -x $UVC_APP_NAME)"
    else
        echo "[uvc-app] not running (无需停止)"
    fi
}

# 以与 run.sh 相同的方式拉起出流应用: cwd=$PUB_DIR, ./uvc-gadget 追加日志。
# setsid 使其脱离本脚本会话, 脚本退出后应用继续存活(防 SIGHUP 误杀)。
start_uvc_app() {
    [ -x "$PUB_DIR/$UVC_APP_NAME" ] || { echo "[uvc-app] 错误: 找不到 $PUB_DIR/$UVC_APP_NAME"; return 1; }
    if uvc_app_alive; then
        echo "[uvc-app] already running (pid $(cat $UVC_APP_PID 2>/dev/null))"
        return 0
    fi
    pkill -x "$UVC_APP_NAME" 2>/dev/null
    rm -f "$UVC_APP_PID"
    # 复刻 run.sh 导出的运行环境
    export PATH="$PUB_DIR:$PATH"
    export LD_LIBRARY_PATH="$PUB_DIR:${LD_LIBRARY_PATH:-}"
    mkdir -p "$PID_DIR" 2>/dev/null
    ( cd "$PUB_DIR" && exec setsid ./$UVC_APP_NAME >> "$UVC_APP_LOG" 2>&1 < /dev/null ) &
    echo $! > "$UVC_APP_PID"
    sleep 2
    if kill -0 $(cat $UVC_APP_PID 2>/dev/null) 2>/dev/null; then
        echo "[uvc-app] started (pid $(cat $UVC_APP_PID), log $UVC_APP_LOG)"
        return 0
    fi
    rm -f "$UVC_APP_PID"
    echo "[uvc-app] WARN: 启动 2s 内退出, 日志尾部:"
    tail -n 6 "$UVC_APP_LOG" 2>/dev/null
    return 1
}

# ---- UVC 功能 ------------------------------------------------------

remove_uvc() {
    rm -f $GADGET/configs/c.1/uvc.0
    F=$GADGET/functions/uvc.0
    [ -d "$F" ] || { echo "[uvc] nothing to remove"; return 0; }
    # 1) 删除全部符号链接(configfs 目录带链接无法 rmdir)
    rm -f $F/control/class/fs/h $F/control/class/ss/h
    rm -f $F/streaming/class/fs/h $F/streaming/class/hs/h $F/streaming/class/ss/h
    rm -f $F/streaming/header/h/m $F/streaming/header/h/u
    # 2) 删除格式与头目录(从深到浅; 失败即非空, 无害)
    rmdir $F/streaming/uncompressed/u/1200p 2>/dev/null
    rmdir $F/streaming/uncompressed/u 2>/dev/null
    rmdir $F/streaming/mjpeg/m/1200p 2>/dev/null
    rmdir $F/streaming/mjpeg/m 2>/dev/null
    rmdir $F/streaming/header/h 2>/dev/null
    rmdir $F/control/header/h 2>/dev/null
    # 3) 清理空壳目录链(class 目录等)
    rmdir $F/streaming/class/fs $F/streaming/class/hs $F/streaming/class/ss 2>/dev/null
    rmdir $F/streaming/class 2>/dev/null
    rmdir $F/streaming/mjpeg $F/streaming/uncompressed $F/streaming/header 2>/dev/null
    rmdir $F/control/class/fs $F/control/class/ss $F/control/class 2>/dev/null
    rmdir $F/streaming $F/control 2>/dev/null
    # 4) 删除 function 根目录并验证
    if rmdir $F 2>/dev/null; then
        echo "[uvc] removed"
    else
        echo "[uvc] WARN: uvc.0 未完全删除, 残留内容:"
        ls -R $F 2>/dev/null
        echo "[uvc] 残留空壳一般无害(下次 create 会复用); 若后续报错可重启恢复"
    fi
}

create_uvc() {
    F=$GADGET/functions/uvc.0
    # 显式建齐所有目录(含 class), 不依赖上次残留
    mkdir -p $F/control/header/h $F/control/class/fs $F/control/class/ss
    mkdir -p $F/streaming/header/h
    mkdir -p $F/streaming/class/fs $F/streaming/class/hs $F/streaming/class/ss
    mkdir -p $F/streaming/mjpeg/m/1200p $F/streaming/uncompressed/u/1200p
    for fmt in mjpeg/m uncompressed/u; do
        D=$F/streaming/$fmt/1200p
        echo 1600 > $D/wWidth
        echo 1200 > $D/wHeight
        echo 3840000 > $D/dwMaxVideoFrameBufferSize
        printf "10000000\n20000000\n" > $D/dwFrameInterval
    done
    ( cd $F/streaming/header/h && ln -s ../../mjpeg/m && ln -s ../../uncompressed/u )
    ( cd $F/streaming/class/fs && ln -s ../../header/h )
    ( cd $F/streaming/class/hs && ln -s ../../header/h )
    ( cd $F/streaming/class/ss && ln -s ../../header/h )
    ( cd $F/control && ln -s header/h class/fs && ln -s header/h class/ss )
    echo 3072 > $F/streaming_maxpacket
    echo $UVC_VID > $GADGET/idVendor
    echo $UVC_PID > $GADGET/idProduct
    # configfs 符号链接创建时会解析 target; 相对路径按 cwd 解析,
    # 必须 cd 到 g1 目录再 ln(与 uvc-gadget.sh 一致), 否则报 ENOENT。
    # ln 前先清残留 configs 链接, 防止把已有链接当目录用(Operation not permitted)。
    rm -f $GADGET/configs/c.1/uvc.0
    ( cd $GADGET && ln -s functions/uvc.0 configs/c.1/uvc.0 )
    echo "[uvc] created (1600x1200 mjpeg+uncompressed)"
}

# ---- RNDIS 功能 ----------------------------------------------------

remove_rndis() {
    # 先删 configs 链接, 再删函数目录 —— 链接残留会让下次 ln 把已存在
    # 的链接当目录用而报 "Operation not permitted"(2026-09-02 实测)。
    rm -f $GADGET/configs/c.1/rndis.0
    # 清理 usb0 旧配置(切换后网卡会消失)
    ip link set usb0 down 2>/dev/null
    ip addr flush dev usb0 2>/dev/null
    if rmdir $GADGET/functions/rndis.0 2>/dev/null; then
        echo "[rndis] removed"
    elif [ -d $GADGET/functions/rndis.0 ]; then
        echo "[rndis] WARN: functions/rndis.0 目录残留(非空?)"
    else
        echo "[rndis] nothing to remove"
    fi
}

create_rndis() {
    echo $RNDIS_VID > $GADGET/idVendor
    echo $RNDIS_PID > $GADGET/idProduct
    # 幂等: 清掉可能残留的 configs 链接(防 ln 当目录用), 目录存在则跳过 mkdir
    rm -f $GADGET/configs/c.1/rndis.0
    [ -d $GADGET/functions/rndis.0 ] || mkdir $GADGET/functions/rndis.0
    # 同上: 相对 target 依赖 cwd, 必须 cd 到 g1 再 ln。
    ( cd $GADGET && ln -s functions/rndis.0 configs/c.1/rndis.0 )
    echo "[rndis] created"
}

# ---- 状态 / 模式判断 ----------------------------------------------

current_mode() {
    [ -d $GADGET/functions/rndis.0 ] && { echo rndis; return; }
    [ -d $GADGET/functions/uvc.0 ]   && { echo uvc;   return; }
    case "$(cat $GADGET/idProduct 2>/dev/null)" in
        "$RNDIS_PID") echo rndis ;;
        "$UVC_PID")   echo uvc   ;;
        *)            echo unknown ;;
    esac
}

status() {
    echo "== gadget =="
    echo "gadget dir : $(ls /sys/kernel/config/usb_gadget/ 2>/dev/null)"
    echo "functions  : $(ls $GADGET/functions/ 2>/dev/null)"
    echo "configs/c.1: $(ls $GADGET/configs/c.1/ 2>/dev/null | tr '\n' ' ')"
    echo "VID:PID    : $(cat $GADGET/idVendor 2>/dev/null):$(cat $GADGET/idProduct 2>/dev/null)"
    echo "当前模式   : $(current_mode)"
    echo "== UDC =="
    ST=$(cat /sys/class/udc/$UDC/state 2>/dev/null)
    echo "controller : $(cat $GADGET/UDC 2>/dev/null)  state: $ST"
    case "$ST" in
        configured) echo "枚举状态  : 正常(主机已完成枚举)" ;;
        "not attached") echo "枚举状态  : 主机不在线(查 OTG 线/供电, 或 rec-dwc3-recovery.sh)" ;;
        *)
            echo "枚举状态  : 半枚举/未完成 —— 可执行 sudo $0 replug 强制重枚举"
            ;;
    esac
    echo "== usb0 网络 =="
    if usb0_exists; then
        ip addr show usb0 2>/dev/null | grep -E '^[0-9]+:|inet ' || true
        if ip link show usb0 2>/dev/null | grep -q LOWER_UP; then
            echo "carrier   : UP (Windows 网卡链路在线)"
        else
            echo "carrier   : DOWN (Windows 侧网卡未连上)"
        fi
    else
        echo "usb0 不存在(RNDIS 未启用或已切到 UVC)"
    fi
    echo "== DHCP(usb0) =="
    if [ -f $DHCP_PID ] && kill -0 $(cat $DHCP_PID 2>/dev/null) 2>/dev/null; then
        echo "dnsmasq: running (pid $(cat $DHCP_PID)), 主机自动获取 $DHCP_HOST_IP"
        cat $DHCP_LEASE 2>/dev/null | awk '{print "  lease: " $2 " -> " $3 " (" $4 ")"}'
    else
        echo "dnsmasq: not running (仅 RNDIS 模式启用)"
    fi
    echo "== UVC 出流应用(run.sh 生态) =="
    if uvc_app_alive; then
        echo "uvc-gadget: running (pid $(cat $UVC_APP_PID 2>/dev/null))"
    else
        echo "uvc-gadget: not running"
    fi
    echo "== 物理摄像头(Host 口, 与切换无关) =="
    ls /dev/video* 2>/dev/null || echo "无 /dev/video*"
}

# ---- 两个切换动作(供 toggle 复用) ---------------------------------

do_rndis() {
    confirm_unbind
    # 只精确停掉 uvc-gadget 出流应用(虚拟摄像头数据源), 避免活动传输
    # 解绑导致 dwc3 卡死。Core/webCamera/Device/webssh/run.sh 一律不动
    # (run.sh 守护不含 uvc-gadget 且被注释, 不会自动拉起)。
    stop_uvc_app
    sleep 2   # 留时间让主机侧视频流自然断开, 再动 UDC
    unbind_udc
    remove_uvc
    remove_rndis          # 幂等: 清掉上次残留的 rndis, 避免 mkdir File exists
    create_rndis
    bind_udc
    wait_configured       # 未完成枚举则自动摘挂重试, 自愈"主机看不到网卡"
    ip link set usb0 up 2>/dev/null
    ip addr flush dev usb0 2>/dev/null
    ip addr add $RNDIS_IP/24 dev usb0 2>/dev/null
    dhcp_start
    echo "[done] RNDIS 模式, 设备 IP: $RNDIS_IP (Windows 自动获取 $DHCP_HOST_IP)"
    echo "      ping 测试: ping $RNDIS_IP   (Windows 上对设备 IP)"
}

do_uvc() {
    confirm_unbind
    # 先断开主机侧 RNDIS 链路再解绑(09-02 15:41 教训: Windows 活跃 RNDIS
    # 会话下直接 unbind 会系统级冻结; 先 down usb0 让主机网卡进入断开态)。
    if usb0_exists; then
        ip link set usb0 down 2>/dev/null
        ip addr flush dev usb0 2>/dev/null
        sleep 2
    fi
    dhcp_stop
    unbind_udc
    remove_rndis
    remove_uvc            # 幂等: 清掉上次残留的 uvc.0(半成品), 再干净重建
    create_uvc
    bind_udc
    wait_configured
    echo "[done] UVC 模式, 主机应枚举出 UVC 摄像头 (VID $UVC_VID:PID $UVC_PID)"
    if [ "$AUTO_UVC_APP" = "1" ]; then
        echo "[uvc-app] 恢复虚拟摄像头出流应用(仅 uvc-gadget, Core/run.sh 不变)..."
        start_uvc_app || echo "[uvc-app] WARN: 出流应用未能拉起, 见上方日志"
    else
        echo "[hint] 如需恢复虚拟摄像头出流(等价于 run.sh 的启动方式):"
        echo "      sudo $0 uvc-app start"
        echo "      —— 只拉起 uvc-gadget 应用, 不触碰 Core/webCamera/Device/run.sh"
    fi
}

# ---- 主流程 --------------------------------------------------------

case "$1" in
rndis)   require_root rndis; do_rndis ;;
uvc)     require_root uvc;   do_uvc   ;;
replug)  require_root replug; replug_udc ;;
toggle)  require_root toggle
         M=$(current_mode)
         echo "[toggle] 当前模式: $M"
         case "$M" in
             rndis)   do_uvc ;;
             uvc)     do_rndis ;;
             *)       echo "无法判断当前模式, 请显式指定: sudo $0 rndis|uvc"; exit 1 ;;
         esac
         ;;
status)  status ;;
uvc-app) require_root uvc-app
         case "$2" in
             stop)   stop_uvc_app ;;
             start)  start_uvc_app ;;
             status) uvc_app_alive \
                       && echo "uvc-gadget: running (pid $(cat $UVC_APP_PID 2>/dev/null))" \
                       || echo "uvc-gadget: not running" ;;
             *) echo "用法: sudo $0 uvc-app {start|stop|status}"; exit 1 ;;
         esac
         ;;
dhcp)    require_root dhcp
         case "$2" in
             start) dhcp_start ;;
             stop)  dhcp_stop ;;
             *) echo "用法: sudo $0 dhcp {start|stop}"; exit 1 ;;
         esac
         ;;
*)       usage ;;
esac
