#!/bin/sh
# ============================================================
# vnic_down.sh — 关闭虚拟网卡，恢复产品默认 UVC 虚拟摄像头
#
# 用法: sudo sh vnic_down.sh
#
# 说明: 不删除 g1（Rockchip 4.19 删 gadget 会内核 Oops），
#       只做功能级回切 rndis -> uvc。
# ============================================================
set -u
DIR=$(cd "$(dirname "$0")" && pwd)
. "$DIR/vnic_lib.sh"

[ "$(id -u)" = "0" ] || { echo "VNIC_FAIL need root"; exit 1; }

echo "[vnic] switch g1 -> uvc (恢复虚拟摄像头)"
SWITCH_YES=1 sh "$DIR/usb-switch.sh" uvc
RC=$?

echo "[vnic] rc=$RC"
echo "VNIC_DOWN rndis"
ip -br a | grep -E 'usb0' || echo "(usb0 已移除)"
exit 0
