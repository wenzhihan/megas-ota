@echo off
chcp 65001 >nul
setlocal
set "PY=D:/ai_namespace/tools/python-env/Scripts/python.exe"
if not exist "%PY%" set "PY=python"
"%PY%" "%~dp0mega_deploy.py" %*
endlocal
