#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
mega_web.py — Mega 部署工具 Web 控制台（零第三方依赖，标准库实现）

启动:  python mega_deploy.py web        或   python mega_web.py
浏览器: http://127.0.0.1:8765
"""
import json
import os
import queue
import sys
import threading
import time
import traceback
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer

import mega_deploy as md

HOST, PORT = "127.0.0.1", 8765

JOBS = {}
JOB_LOCK = threading.Lock()
CURRENT = {"id": None}


class Tee:
    """把 print 输出同时写进任务缓冲区和控制台"""

    def __init__(self, job, original):
        self.job = job
        self.original = original

    def write(self, s):
        if not s:
            return
        self.job["buf"].append(s)
        try:
            self.original.write(s)
        except Exception:
            pass

    def flush(self):
        try:
            self.original.flush()
        except Exception:
            pass

    def isatty(self):
        return False

    @property
    def encoding(self):
        return "utf-8"


def new_job(title):
    jid = "%d" % int(time.time() * 1000)
    job = {"id": jid, "title": title, "buf": [], "done": False,
           "ok": False, "error": "", "started": time.time()}
    with JOB_LOCK:
        JOBS[jid] = job
        for k in [k for k, v in JOBS.items() if v["done"] and time.time() - v["started"] > 3600]:
            JOBS.pop(k, None)
    return job


def run_job(title, fn):
    if CURRENT["id"]:
        cur = JOBS.get(CURRENT["id"])
        if cur and not cur["done"]:
            raise RuntimeError("已有任务在执行，请等待完成")
    job = new_job(title)
    CURRENT["id"] = job["id"]

    def worker():
        old = sys.stdout
        sys.stdout = Tee(job, old)
        try:
            fn()
            job["ok"] = True
        except Exception as e:
            job["error"] = str(e)
            print("\n[错误] %s" % e)
            traceback.print_exc()
        finally:
            sys.stdout = old
            job["done"] = True

    threading.Thread(target=worker, daemon=True).start()
    return job


# ------------------------------------------------------------------ 动作
def act_probe(a):
    dev = md.MegaDevice(a["ip"], a.get("user"), a.get("password"))
    try:
        dev.connect()
        print("已连接 %s@%s" % (dev.user, dev.host))
        sec = md.parse_sections(md.probe(dev))
        for k in ("OS", "IFACES", "ROUTE", "UDC", "GADGET", "PUB", "TEST", "SVC", "PROCS", "PORTS", "RUNSH"):
            print("\n== %s ==" % k)
            print(sec.get(k, "(空)"))
    finally:
        dev.close()


def act_vnic(a):
    dev = md.MegaDevice(a["ip"], a.get("user"), a.get("password"))
    try:
        dev.connect()
        act = a["action"]
        if act == "install":
            print("安装虚拟网卡环境到 %s（并设为开机自启）" % a["ip"])
            ok, out, err = md.vnic_install(dev, start=a.get("start", True))
            print(out.strip())
            if err.strip():
                print("[stderr] " + err.strip())
            if not ok:
                raise RuntimeError("安装失败")
            print("\n开机自启: mega-vnic.service enabled -> 重启后自动开启 usb0")
        elif act == "uninstall":
            print("卸载虚拟网卡服务（保留脚本）")
            ok, out, err = md.vnic_install(dev, uninstall=True)
            print(out.strip())
            if not ok:
                raise RuntimeError("卸载失败")
        elif act == "up":
            print("开启虚拟网卡: %s -> %s" % (a["ip"], a.get("vnic_ip")))
            ok, out, err = md.vnic_up(dev, a.get("vnic_ip", "192.168.42.1/24"),
                                      a.get("dhcp_ip", "192.168.42.100"))
            print(out.strip())
            if err.strip():
                print("[stderr] " + err.strip())
            if not ok:
                raise RuntimeError("虚拟网卡开启失败")
            print("\nPC 侧：RNDIS 网卡应自动出现并取到 %s；未取到则重启该网卡或手动配同网段 IP"
                  % a.get("dhcp_ip", "192.168.42.100"))
            print(md.pc_rndis_adapters())
        elif act == "down":
            print("关闭虚拟网卡并恢复 UVC 虚拟摄像头")
            ok, out, err = md.vnic_down(dev)
            print(out.strip())
            if err.strip():
                print("[stderr] " + err.strip())
            if not ok:
                raise RuntimeError("关闭失败")
        else:
            print(md.vnic_status(dev))
    finally:
        dev.close()


def act_deploy(a):
    files = a.get("files") or ["Device", "Core", "MegaTest"]
    dev = md.MegaDevice(a["ip"], a.get("user"), a.get("password"))
    try:
        dev.connect()
        print("目标 %s -> %s" % (a["ip"], a.get("dest", md.PUB_DIR)))
        print("文件: %s\n" % ", ".join(files))
        res = md.deploy(dev, files, dest=a.get("dest", md.PUB_DIR),
                        restart=bool(a.get("restart")),
                        backup=bool(a.get("backup", True)))
        print("\n== 部署结果 ==")
        for u in res["uploaded"]:
            print("  %-9s -> %s  md5 %s" % (u["name"], u["path"], u["md5"]))
        print("  run.sh : %s" % res["runsh"])
        if res["restart"]:
            print("  restart: %s" % res["restart"])
        v = res["verify"] or {}
        print("\n== 运行状态 ==")
        for k in ("ACTIVE", "PROCS", "PORTS"):
            print("  %-8s %s" % (k + ":", (v.get(k) or "(空)").replace("\n", " | ")))
        print("\n== core.log 末尾 ==")
        print((v.get("CORE_LOG") or "(无)"))
    finally:
        dev.close()


def act_svc(a):
    dev = md.MegaDevice(a["ip"], a.get("user"), a.get("password"))
    try:
        dev.connect()
        r = md.svc(dev, a["action"])
        if a["action"] == "status":
            for k in ("ACTIVE", "PROCS", "PORTS"):
                print("  %-8s %s" % (k + ":", (r.get(k) or "(空)").replace("\n", " | ")))
        else:
            print("rc=%s %s" % (r["rc"], r["msg"]))
            st = r["state"]
            print("  ACTIVE: %s" % (st.get("ACTIVE") or "").strip())
            print("  PORTS : %s" % (st.get("PORTS") or "(空)").replace("\n", " | "))
        if a["action"] != "status":
            print("\n== 启动日志 ==")
            print(dev.run("tail -n 15 %s/log/system_startup.log" % md.PUB_DIR)[1])
    finally:
        dev.close()


def act_logs(a):
    dev = md.MegaDevice(a["ip"], a.get("user"), a.get("password"))
    try:
        dev.connect()
        print(md.tail_logs(dev, int(a.get("n", 60)), a.get("log", "core")))
    finally:
        dev.close()


ACTIONS = {
    "probe": ("环境探测", act_probe),
    "vnic": ("虚拟网卡", act_vnic),
    "deploy": ("部署二进制", act_deploy),
    "svc": ("服务控制", act_svc),
    "logs": ("查看日志", act_logs),
}


# ------------------------------------------------------------------ HTTP
class Handler(BaseHTTPRequestHandler):
    def log_message(self, *a):
        pass

    def _send(self, code, body, ctype="application/json; charset=utf-8"):
        data = body.encode("utf-8") if isinstance(body, str) else body
        self.send_response(code)
        self.send_header("Content-Type", ctype)
        self.send_header("Content-Length", str(len(data)))
        self.send_header("Cache-Control", "no-store")
        self.end_headers()
        self.wfile.write(data)

    def do_GET(self):
        path = self.path.split("?")[0]
        if path in ("/", "/index.html"):
            self._send(200, PAGE, "text/html; charset=utf-8")
        elif path == "/api/stream":
            jid = self.path.split("id=")[-1]
            self._stream(jid)
        elif path == "/api/devices":
            self._send(200, json.dumps({"devices": md.load_config().get("devices", []),
                                        "defaults": md.defaults()}, ensure_ascii=False))
        else:
            self._send(404, "{}")

    def do_POST(self):
        n = int(self.headers.get("Content-Length", 0))
        try:
            body = json.loads(self.rfile.read(n).decode("utf-8") or "{}")
        except Exception:
            self._send(400, json.dumps({"error": "bad json"}))
            return
        path = self.path.split("?")[0]
        if path == "/api/devices/save":
            self._save_device(body)
            return
        if path == "/api/devices/delete":
            self._delete_device(body)
            return
        action = body.get("action")
        if action not in ACTIONS:
            self._send(400, json.dumps({"error": "unknown action"}, ensure_ascii=False))
            return
        title, fn = ACTIONS[action]
        try:
            job = run_job(title, lambda: fn(body))
        except Exception as e:
            self._send(409, json.dumps({"error": str(e)}, ensure_ascii=False))
            return
        self._send(200, json.dumps({"job": job["id"]}, ensure_ascii=False))

    # -- 设备预设维护 --
    def _save_device(self, body):
        host = (body.get("host") or "").strip()
        if not host:
            self._send(400, json.dumps({"error": "IP 不能为空"}, ensure_ascii=False))
            return
        cfg = md.load_config()
        devs = cfg.setdefault("devices", [])
        item = {"name": (body.get("name") or host).strip(), "host": host,
                "user": (body.get("user") or "cat").strip(),
                "password": body.get("password") or "temppwd",
                "note": (body.get("note") or "").strip()}
        for i, d in enumerate(devs):
            if d.get("host") == host:
                devs[i] = item
                break
        else:
            devs.append(item)
        with open(md.CONFIG_PATH, "w", encoding="utf-8") as f:
            json.dump(cfg, f, ensure_ascii=False, indent=2)
        self._send(200, json.dumps({"ok": True, "devices": devs}, ensure_ascii=False))

    def _delete_device(self, body):
        host = (body.get("host") or "").strip()
        cfg = md.load_config()
        cfg["devices"] = [d for d in cfg.get("devices", []) if d.get("host") != host]
        with open(md.CONFIG_PATH, "w", encoding="utf-8") as f:
            json.dump(cfg, f, ensure_ascii=False, indent=2)
        self._send(200, json.dumps({"ok": True, "devices": cfg["devices"]}, ensure_ascii=False))

    def _stream(self, jid):
        job = JOBS.get(jid)
        if not job:
            self._send(404, "{}")
            return
        self.send_response(200)
        self.send_header("Content-Type", "text/event-stream; charset=utf-8")
        self.send_header("Cache-Control", "no-store")
        self.end_headers()
        idx = 0
        try:
            while True:
                while idx < len(job["buf"]):
                    chunk = "".join(job["buf"][idx:])
                    idx = len(job["buf"])
                    payload = json.dumps({"t": "out", "v": chunk}, ensure_ascii=False)
                    self.wfile.write(("data: %s\n\n" % payload).encode("utf-8"))
                    self.wfile.flush()
                if job["done"]:
                    payload = json.dumps({"t": "done", "ok": job["ok"],
                                          "error": job["error"]}, ensure_ascii=False)
                    self.wfile.write(("data: %s\n\n" % payload).encode("utf-8"))
                    self.wfile.flush()
                    break
                time.sleep(0.12)
        except (BrokenPipeError, ConnectionResetError):
            pass


PAGE = r"""<!DOCTYPE html>
<html lang="zh-CN"><head><meta charset="utf-8">
<title>Mega 部署工具</title>
<style>
:root{--bg:#f5f6f8;--card:#fff;--line:#e3e6ea;--txt:#1d2129;--sub:#61666d;--pri:#1664ff;--ok:#00a870;--warn:#d4380d;--code:#0f172a}
*{box-sizing:border-box}
body{margin:0;background:var(--bg);color:var(--txt);font:14px/1.6 -apple-system,"Segoe UI","Microsoft YaHei",sans-serif}
.wrap{max-width:1180px;margin:0 auto;padding:22px}
h1{font-size:20px;margin:0 0 4px}
.sub{color:var(--sub);font-size:13px;margin-bottom:18px}
.grid{display:grid;grid-template-columns:380px 1fr;gap:16px}
.card{background:var(--card);border:1px solid var(--line);border-radius:10px;padding:16px}
.card h2{font-size:13px;color:var(--sub);font-weight:600;margin:0 0 12px;letter-spacing:.4px}
label{display:block;font-size:12px;color:var(--sub);margin:10px 0 4px}
input,select{width:100%;padding:7px 9px;border:1px solid var(--line);border-radius:6px;font:13px/1.4 inherit;background:#fff}
input:focus,select:focus{outline:none;border-color:var(--pri)}
.row{display:flex;gap:8px}.row>*{flex:1}
.chk{display:flex;gap:14px;flex-wrap:wrap;margin-top:8px}
.chk label{display:flex;align-items:center;gap:6px;margin:0;font-size:13px;color:var(--txt)}
.chk input{width:auto}
.btns{display:grid;grid-template-columns:1fr 1fr;gap:8px;margin-top:16px}
button{padding:8px 10px;border:1px solid var(--line);border-radius:6px;background:#fff;color:var(--txt);font:13px inherit;cursor:pointer}
button:hover{border-color:var(--pri);color:var(--pri)}
button.pri{background:var(--pri);border-color:var(--pri);color:#fff}
button.pri:hover{background:#0e4fd8;color:#fff}
button:disabled{opacity:.5;cursor:not-allowed}
.term{background:var(--code);color:#d7e2f0;border-radius:10px;padding:14px;height:560px;overflow:auto;
      font:12.5px/1.55 Consolas,"Courier New",monospace;white-space:pre-wrap;word-break:break-all}
.term .ok{color:#7ee787}.term .err{color:#ff9b8a}
.hint{color:var(--sub);font-size:12px;margin-top:10px;line-height:1.5}
.badge{display:inline-block;padding:1px 8px;border-radius:10px;background:#eef4ff;color:var(--pri);font-size:12px}
</style></head><body><div class="wrap">
<h1>Mega 部署工具 <span class="badge" id="conn">未连接</span></h1>
<div class="sub">虚拟网卡环境配置 · Device / Core / MegaTest 传输部署 · 服务启停与验证</div>
<div class="grid">
  <div>
    <div class="card">
      <h2>目标设备</h2>
      <label>预设设备</label>
      <select id="dev"><option value="">自定义 IP</option></select>
      <div class="row" style="margin-top:6px">
        <div><label>名称（保存用）</label><input id="devname" placeholder="如 181 测试机"></div>
        <div style="max-width:150px;display:flex;align-items:flex-end;gap:6px">
          <button onclick="saveDev()" style="flex:1">保存预设</button>
          <button onclick="delDev()" style="flex:1">删除</button>
        </div>
      </div>
      <div class="row"><div><label>IP</label><input id="ip" value="192.168.112.181"></div>
        <div style="max-width:90px"><label>端口</label><input id="port" value="22"></div></div>
      <div class="row"><div><label>用户</label><input id="user" value="cat"></div>
        <div><label>密码</label><input id="pwd" type="password" value="temppwd"></div></div>

      <h2 style="margin-top:18px">虚拟网卡（设备侧 · 开机自启）</h2>
      <div class="row">
        <div><label>设备地址/CIDR</label><input id="vnicip" value="192.168.42.1/24"></div>
        <div><label>DHCP 给 PC</label><input id="dhcpip" value="192.168.42.100"></div>
      </div>
      <div class="btns">
        <button class="pri" onclick="go('vnic',{action:'install',start:true})">安装并开机自启</button>
        <button onclick="go('vnic',{action:'up'})">立即开启</button>
        <button onclick="go('vnic',{action:'down'})">关闭(恢复UVC)</button>
        <button onclick="go('vnic',{action:'status'})">状态</button>
      </div>

      <h2 style="margin-top:18px">部署内容</h2>
      <div class="chk">
        <label><input type="checkbox" class="f" value="Device" checked>Device</label>
        <label><input type="checkbox" class="f" value="Core" checked>Core</label>
        <label><input type="checkbox" class="f" value="MegaTest" checked>MegaTest</label>
      </div>
      <label>目标目录</label><input id="dest" value="/home/cat/pub">
      <div class="chk">
        <label><input type="checkbox" id="restart" checked>部署后重启服务</label>
        <label><input type="checkbox" id="backup" checked>备份旧文件</label>
      </div>
      <div class="btns"><button class="pri" onclick="deploy()">上传并部署</button>
        <button onclick="go('probe')">环境探测</button></div>
      <div class="btns" style="margin-top:8px">
        <button onclick="go('svc',{action:'start'})">启动</button>
        <button onclick="go('svc',{action:'stop'})">停止</button>
        <button onclick="go('svc',{action:'restart'})">重启</button>
        <button onclick="go('svc',{action:'status'})">状态</button>
      </div>
      <div class="btns" style="margin-top:8px">
        <button onclick="go('logs',{log:'core',n:80})">core.log</button>
        <button onclick="go('logs',{log:'system_startup',n:60})">启动日志</button>
      </div>
      <div class="hint">RNDIS 模式：设备端 usb0 固定为上面填的地址，PC 侧需给“USB Ethernet/RNDIS”网卡配同网段地址（如 192.168.42.2）。</div>
    </div>
  </div>
  <div class="card" style="padding:12px">
    <div class="term" id="term">就绪。选择设备后点任意操作。</div>
  </div>
</div></div>
<script>
const $=id=>document.getElementById(id);
let busy=false;
function refreshDevices(sel){
  fetch('/api/devices').then(r=>r.json()).then(d=>{
    const box=$('dev');const keep=sel||box.value;
    box.innerHTML='<option value="">自定义 IP</option>';
    (d.devices||[]).forEach(x=>{const o=document.createElement('option');o.value=x.host;
      o.textContent=x.name+'  ('+x.host+')';box.appendChild(o);});
    if(keep)box.value=keep;
    window._devs=d.devices||[];
    if(d.defaults&&d.defaults.user&&!$('user').dataset.touched){
      $('user').value=d.defaults.user;$('pwd').value=d.defaults.password;}
  });
}
$('dev').onchange=()=>{const v=$('dev').value;if(!v)return;
  const hit=(window._devs||[]).find(x=>x.host===v);
  $('ip').value=v;
  if(hit){$('user').value=hit.user||'cat';$('pwd').value=hit.password||'temppwd';
    $('devname').value=hit.name||'';}};
function saveDev(){
  const body={name:$('devname').value.trim()||$('ip').value.trim(),host:$('ip').value.trim(),
    user:$('user').value.trim(),password:$('pwd').value};
  if(!body.host){alert('先填 IP');return;}
  fetch('/api/devices/save',{method:'POST',headers:{'Content-Type':'application/json'},
    body:JSON.stringify(body)}).then(r=>r.json()).then(d=>{
      if(d.error){alert(d.error);return;}
      refreshDevices(body.host);term('\n[预设已保存] '+body.name+' -> '+body.host+'\n','ok');});
}
function delDev(){
  const host=$('dev').value||$('ip').value.trim();
  if(!host){return;}
  if(!confirm('删除预设 '+host+' ?'))return;
  fetch('/api/devices/delete',{method:'POST',headers:{'Content-Type':'application/json'},
    body:JSON.stringify({host})}).then(r=>r.json()).then(d=>{
      refreshDevices('');term('\n[预设已删除] '+host+'\n','ok');});
}
refreshDevices();
function base(){return {ip:$('ip').value.trim(),user:$('user').value.trim(),
  password:$('pwd').value,port:parseInt($('port').value||'22'),
  vnic_ip:$('vnicip').value.trim(),dhcp_ip:$('dhcpip').value.trim()};}
function files(){return [...document.querySelectorAll('.f:checked')].map(e=>e.value);}
function deploy(){if(!files().length){alert('至少选一个文件');return;}
  go('deploy',{files:files(),dest:$('dest').value.trim(),
    restart:$('restart').checked,backup:$('backup').checked});}
function term(t,cls){const el=$('term');const s=document.createElement('span');
  if(cls)s.className=cls;s.textContent=t;el.appendChild(s);el.scrollTop=el.scrollHeight;}
function go(action,extra){
  if(busy){term('\n[提示] 上一个任务还没结束\n');return;}
  const body=Object.assign(base(),{action},extra||{});
  $('term').textContent='';
  term('> '+action+' @ '+body.ip+'\n\n');
  busy=true;setBadge('执行中','#d4380d');
  fetch('/api/'+(action==='probe'||action==='logs'||action==='svc'?'run':'run'),
    {method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify(body)})
  .then(async r=>{const j=await r.json();
    if(j.error){term('\n[错误] '+j.error+'\n');busy=false;setBadge('失败','#d4380d');return;}
    const es=new EventSource('/api/stream?id='+j.job);
    es.onmessage=e=>{const m=JSON.parse(e.data);
      if(m.t==='out')term(m.v);
      if(m.t==='done'){es.close();busy=false;
        if(m.ok){setBadge('就绪','#00a870');term('\n\n✔ 完成\n','ok');}
        else{setBadge('失败','#d4380d');term('\n✘ '+(m.error||'失败')+'\n','err');}}};
  }).catch(e=>{term('\n[网络错误] '+e+'\n');busy=false;});
}
function setBadge(t,c){const b=$('conn');b.textContent=t;b.style.color=c;b.style.background=c+'18';}
</script></body></html>"""


def serve():
    cfg = md.load_config().get("defaults", {})
    url = "http://%s:%d" % (HOST, PORT)
    print("Mega 部署控制台: %s" % url)
    print("（Ctrl+C 停止）")
    try:
        import webbrowser
        webbrowser.open(url)
    except Exception:
        pass
    srv = ThreadingHTTPServer((HOST, PORT), Handler)
    try:
        srv.serve_forever()
    except KeyboardInterrupt:
        print("\n已停止")


if __name__ == "__main__":
    serve()
