# Mega 部署工具（mega_deploy）

PC 侧轻量工具：通过 SSH 把 **Device / Core / MegaTest** 部署到任意可登录的 Mega 设备，
并提供设备侧**虚拟网卡**（USB RNDIS / tun）环境配置能力。

- 形态：Python CLI + 本地 Web 控制台（浏览器打开，无第三方 GUI 依赖）
- 传输：paramiko（SFTP），带进度、逐文件 md5 校验
- 已验证设备：`192.168.112.181`（LubanCat RK3568 / Ubuntu 20.04.6 / 内核 4.19.232）

---

## 目录结构

```
E:\demo\mega_deploy\
├── mega_deploy.py        CLI 主程序（连接/探测/部署/服务/日志）
├── mega_web.py           Web 控制台（http://127.0.0.1:8765）
├── config.json           设备预设（UI 可增删改，写入本文件）
├── payload\              部署载荷（二进制就在工程内）
│   ├── Device            573,648 B   md5 c6b3a121161b8b8e7bee27afbdc0af68
│   ├── Core           36,525,480 B   md5 c79a26652775357874ae53192f4a76f5
│   └── MegaTest          288,448 B   md5 c5b540d80d6af5844da9337325e8a97a
├── scripts\
│   ├── usb-switch.sh     切换引擎（UVC<->RNDIS，RK3568 六验版）
│   ├── vnic_lib.sh       公共函数（gadget/UDC/usb0/dnsmasq）
│   ├── vnic_up.sh        开启虚拟网卡 + DHCP 重试
│   ├── vnic_down.sh      关闭并恢复 UVC
│   ├── vnic_boot.sh      开机入口（含三级自愈）
│   ├── vnic_status.sh    状态总览
│   ├── vnic_install.sh   安装到 /home/cat/mega_deploy + 装 NM 静态档 + 启服务
│   └── mega-vnic.service 开机自启单元
├── run_cli.bat           命令行入口
├── run_gui.bat           Web 控制台入口
└── README.md
```

载荷来源：dev_yjj 纯净提交内容（`b5d97e0` + BSP `90e839da`）编译产物，见
`D:\ai_namespace\mega_release\release_dev_yjj_b5d97e0_20261111\manifest.txt`。
MegaTest 因依赖未提交的 BSP 接口，由主仓本地树构建（md5 与 10/29 既有产物一致）。

---

## 快速开始

```bat
run_gui.bat                 :: 打开 http://127.0.0.1:8765
run_cli.bat list            :: 列出设备预设
run_cli.bat probe  --ip 192.168.112.181
run_cli.bat deploy --ip 192.168.112.181 --files Device,Core,MegaTest --restart
```

Python 解释器：默认 `D:\ai_namespace\tools\python-env\Scripts\python.exe`（含 paramiko）；
不存在时回退 `python`（需 `pip install paramiko`）。

---

## 部署流程（第一部分，已实测通过）

`deploy` 严格按下面顺序执行，避免"进程占用旧二进制"与"半包不可用"：

1. **停止**：`systemctl stop ntmega` + `pkill -x Core/Device`，并统计残留进程
2. **备份**：`/home/cat/pub/backup_<时间戳>/` 下保存将被覆盖的旧文件
3. **上传**：SFTP 传到 `/tmp/mega_deploy_<ts>/`，逐文件比对 md5（不一致即中止）
4. **落位**：`install -m 755 <tmp>/X <目标>/X.new` → `mv -f` 原子替换
5. **恢复 run.sh**：`pub/run.sh` 缺失时从 `run.sh_bask` 恢复并加可执行位
6. **启动**：`systemctl daemon-reload` + `systemctl start --no-block ntmega`
7. **验证**：服务状态、进程、端口（1888 Core / 1889 Device / 5000 TCP）、core.log 末尾

文件落点：

| 文件 | 目标路径 |
|---|---|
| Device | `/home/cat/pub/Device` |
| Core | `/home/cat/pub/Core` |
| MegaTest | `/home/cat/MegaTest` |

### 181 实测结果（2026-11-12 16:38）

```
已停止 ntmega (原状态 inactive)，残留进程 0 个
备份 -> /home/cat/pub/backup_20261112_163802
Device    md5 c6b3a121... OK
Core      md5 c79a2665... OK   (34.8 MB @ 4.6 MB/s)
MegaTest  md5 c5b540d8... OK
已恢复 run.sh（来自 run.sh_bask）
ntmega start rc=0 state=active

PROCS:  2843 ./Core | 2812 ./Device
PORTS:  0.0.0.0:5000  *:1888  *:1889
core.log: [TCP] Listening on port 5000 / [UART] send msgs=2 bytes=78 ...
MegaTest 运行: 正常打印 "MegaTest - Device Control & Test Tool" 帮助
```

---

## 虚拟网卡（第二部分，已在 181 实测通过 · 开机自启）

设备侧建 USB RNDIS 虚拟网卡，给 Core/Device 一个**不依赖 WiFi DHCP** 的固定地址；
PC 插上 OTG 线即出现 RNDIS 网卡并自动拿到 `192.168.42.100`。

```bat
run_cli.bat vnic install --ip 192.168.112.181          :: 安装 + 开机自启（不立即切换）
run_cli.bat vnic install --ip 192.168.112.181 --start  :: 安装并立即生效
run_cli.bat vnic up      --ip 192.168.112.181          :: 立即开启（未安装会自动安装）
run_cli.bat vnic down    --ip 192.168.112.181          :: 关闭，恢复 UVC 虚拟摄像头
run_cli.bat vnic status  --ip 192.168.42.1
run_cli.bat svc enable   --ip 192.168.112.181          :: 顺带让 Core 也开机自启
```

### 设备侧落地内容（`vnic install` 后）

| 路径 | 说明 |
|---|---|
| `/home/cat/mega_deploy/usb-switch.sh` | 切换引擎（RK3568 六验版，VID/PID 改为 `1d6b:0104`，规避本机 oem16.inf 抢绑） |
| `vnic_lib.sh / vnic_up.sh / vnic_down.sh / vnic_boot.sh / vnic_status.sh` | 封装层：建 gadget、配 IP、开机自愈、状态 |
| `/etc/systemd/system/mega-vnic.service` | **开机自启单元**（enabled，Type=oneshot，After=ntmega） |
| `/etc/NetworkManager/system-connections/mega-vnic-usb0.nmconnection` | usb0 静态 `192.168.42.1/24`，`never-default`，替代 NM 自动生成的 DHCP 档 |
| `/home/cat/pub/log/mega-vnic.log` | 开机流程日志 |

### 开机流程

```
ntmega（若启用）建 g1(UVC)  →  mega-vnic.service
   ├─ g1 不存在则自建骨架（Rockchip 4.19 只允许一个 gadget，绝不新建第二个）
   ├─ 功能级切换 g1: uvc.0 → rndis.0（先解绑 UDC，不删 gadget）
   ├─ usb0 up + 192.168.42.1/24，dnsmasq 起 DHCP（给 PC 192.168.42.100）
   └─ 未完成枚举则三级自愈：UDC 摘挂 → dwc3 平台驱动重载（各 3 轮）
```

### 181 实测记录（2026-11-12）

| 场景 | 结果 |
|---|---|
| 手动开启 | g1 由 uvc.0 换成 rndis.0，`1d6b:0104`，usb0 = 192.168.42.1/24 |
| PC 侧 | 出现「Remote NDIS based Internet Sharing Device」(Ethernet 11)，DHCP 拿到 `192.168.42.100/24`，网关 192.168.42.1 |
| 连通性 | `ping 192.168.42.1` 4/4、0% 丢包、0ms；**SSH 经 192.168.42.1 登录成功** |
| 重启（ntmega 关闭） | mega-vnic.service active，usb0 自动恢复，DHCP 正常 |
| 重启（ntmega 启用） | Core/Device 起来 + 虚拟网卡恢复；切换后 `not attached` → replug 无效 → **dwc3 重载自愈到 configured** |

### 排查要点（踩过的坑）

1. **开机 dnsmasq 报 `unknown interface usb0`**：usb0 注册有延迟 → `vnic_up.sh` 内置 5 次重试。
2. **usb0 静态 IP 被冲掉**：Ubuntu 的 NetworkManager 会自动生成 DHCP 客户端档 → 安装专用静态 profile 并删除旧档。
3. **RAM 之外的坑**：`kill -0` 对 root 进程返回 EPERM 会误判 dnsmasq 未运行 → 状态检查改用 `ps -p`。
4. **切 UVC→RNDIS 后 `state=not attached`**：先 replug 一次，仍不行则 dwc3 unbind/bind（必须先在解绑 gadget 状态下操作）。
5. OTG 线只接充电线时 `state=not attached` 属正常，接数据口后 `usb-switch.sh replug` 即可。

---

## Web 控制台

- 预设设备下拉选择后自动填充 IP/用户/密码，可**保存**或**删除**预设（写回 config.json）
- 也可直接手填任意 IP（"自定义 IP"）
- 右侧终端实时显示上传进度与部署日志（SSE 流式输出）
- 按钮：环境探测 / 创建·拆除虚拟网卡 / 上传并部署 / 启动·停止·重启·状态 / 查看日志

---

## 备注

- 设备默认凭据 `cat / temppwd`（sudo 同密码），可在 config.json 或 UI 中修改
- `ntmega.service` 为 `Type=oneshot` + `RemainAfterExit`，启动用 `--no-block` 防止常驻脚本卡住调用
- 服务未启用（`disabled`）时不影响手动 `start`；需要开机自启再 `systemctl enable ntmega`

---

## Z 轴往返压测脚本（`scripts/z_stress.sh`）

按 MegaTest `z_ruler_stress <cycles> <z_max> <step>` 的语义封装：G90 逐点走到位 → 等 MCU 空闲
→ `get_interval()` 读测距（raw/10 = mm），上行下行各测一遍，数据落**固定日志**便于长期对比。

默认参数即需求值：**行程 50mm、往返 1000 次、每 1mm 测距**。

```sh
sudo sh z_stress.sh                 # 默认：50mm / 1000 次 / 1mm，且先停 Core
sudo sh z_stress.sh -s 30 -n 500 -d 2
sudo sh z_stress.sh -D              # 后台跑（setsid + pid 文件）
sudo sh z_stress.sh -c              # 跳过“先停 Core”
sudo sh z_stress.sh -C              # 压测结束后重新拉起 Core
sudo sh z_stress.sh -b /home/cat/MegaTest -L /home/cat/pub/log/z.log
```

**压测前默认停 Core**：`systemctl stop ntmega` → 按进程名精确清理残留 `Core`（TERM，1s 后 KILL）
→ 校验无 Core 才继续；Core 仍在则直接中止（避免与 MegaTest 抢 MCU 串口）。
触发顺序在展开参数、写日志头之前，日志头会记录 `core=stopped|kept` 便于回溯。

| 产物 | 路径 |
|---|---|
| 固定日志（累积） | `/home/cat/pub/log/z_stress_50mm_1000.log` |
| 本次原始输出 | `/home/cat/z_stress_runs/<时间戳>/console.log` |
| 本次原始 CSV | `.../z_ruler_stress_*.csv` |
| 本次统计 | `.../summary.txt` |

固定日志格式：`run_id,cycle,direction,z_mm,distance_raw,distance_mm`

- 中止：`Ctrl+C` / `kill`（SIGTERM）— MegaTest 会回零后再退出，已采数据仍会并入固定日志；
- 日志 > 128MB 自动轮转为 `.1`；
- 参数校验：行程必须能被步长整除，需要 root。
