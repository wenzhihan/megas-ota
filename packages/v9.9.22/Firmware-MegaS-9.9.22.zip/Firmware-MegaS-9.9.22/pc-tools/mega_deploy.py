#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
mega_deploy.py — Mega 设备部署工具（CLI 核心）

功能:
  1) 虚拟网卡环境: 设备侧建 USB RNDIS 虚拟网卡(usb0) / tun 网卡，配固定 IP
  2) 文件传输: 把 Device / Core / MegaTest 传到任意可 SSH 的设备
  3) 服务控制: 恢复 run.sh、启停 ntmega.service、看状态与日志
  4) 部署验证: 端口监听、进程、日志、二进制 md5 全链路核对

用法示例:
  python mega_deploy.py list
  python mega_deploy.py probe   --ip 192.168.112.181
  python mega_deploy.py vnic install --ip 192.168.112.181 --start   # 装+开机自启
  python mega_deploy.py vnic up --ip 192.168.112.181 --vnic-ip 192.168.42.1/24
  python mega_deploy.py deploy  --ip 192.168.112.181 --files Device,Core,MegaTest --restart
  python mega_deploy.py svc status --ip 192.168.112.181
  python mega_deploy.py web                 # 打开 Web 控制台
"""
import argparse
import json
import os
import posixpath
import shlex
import socket
import sys
import time
from datetime import datetime

try:
    sys.stdout.reconfigure(encoding="utf-8", errors="replace")
    sys.stderr.reconfigure(encoding="utf-8", errors="replace")
except Exception:
    pass

BASE = os.path.dirname(os.path.abspath(__file__))
CONFIG_PATH = os.path.join(BASE, "config.json")
PAYLOAD_DIR = os.path.join(BASE, "payload")
SCRIPTS_DIR = os.path.join(BASE, "scripts")

# 默认部署清单: 逻辑名 -> (本地文件, 远端目录, 可执行)
PAYLOAD_MAP = {
    "Device":   ("Device",   "/home/cat/pub", True),
    "Core":     ("Core",     "/home/cat/pub", True),
    "MegaTest": ("MegaTest", "/home/cat",     True),
}

PUB_DIR = "/home/cat/pub"


# ---------------------------------------------------------------- 配置
def load_config():
    if os.path.exists(CONFIG_PATH):
        with open(CONFIG_PATH, "r", encoding="utf-8") as f:
            return json.load(f)
    return {"devices": [], "defaults": {}}


def defaults():
    cfg = load_config().get("defaults", {})
    return {
        "user": cfg.get("user", "cat"),
        "password": cfg.get("password", "temppwd"),
        "port": cfg.get("port", 22),
        "dest": cfg.get("dest", PUB_DIR),
    }


# ---------------------------------------------------------------- 日志
def info(msg):
    print(msg, flush=True)


def step(n, total, msg):
    print("[%d/%d] %s" % (n, total, msg), flush=True)


# ---------------------------------------------------------------- 设备连接
class MegaDevice:
    def __init__(self, host, user=None, password=None, port=None, timeout=15):
        d = defaults()
        self.host = host
        self.user = user or d["user"]
        self.password = password or d["password"]
        self.port = int(port or d["port"])
        self.timeout = timeout
        self.client = None
        self.sftp = None

    # -- 连接 --
    def connect(self):
        if self.client:
            return self
        try:
            import paramiko
        except ImportError:
            raise RuntimeError("缺少 paramiko，请先执行: pip install paramiko")
        c = paramiko.SSHClient()
        c.set_missing_host_key_policy(paramiko.AutoAddPolicy())
        c.connect(self.host, port=self.port, username=self.user,
                  password=self.password, timeout=self.timeout,
                  allow_agent=False, look_for_keys=False,
                  banner_timeout=20, auth_timeout=20)
        self.client = c
        self.sftp = c.open_sftp()
        return self

    def close(self):
        try:
            if self.sftp:
                self.sftp.close()
        except Exception:
            pass
        try:
            if self.client:
                self.client.close()
        except Exception:
            pass
        self.sftp = self.client = None

    def __enter__(self):
        return self.connect()

    def __exit__(self, *a):
        self.close()

    # -- 执行 --
    def run(self, cmd, timeout=90, sudo=False, check=False):
        """返回 (rc, stdout, stderr)"""
        self.connect()
        if sudo:
            full = "sudo -S -p '' bash -lc " + shlex.quote(cmd)
        else:
            full = cmd
        stdin, stdout, stderr = self.client.exec_command(full, timeout=timeout)
        if sudo:
            try:
                stdin.write(self.password + "\n")
                stdin.flush()
            except Exception:
                pass
        out = stdout.read().decode("utf-8", "replace")
        err = stderr.read().decode("utf-8", "replace")
        rc = stdout.channel.recv_exit_status()
        if check and rc != 0:
            raise RuntimeError("命令失败(rc=%d): %s\n%s" % (rc, cmd, err.strip()))
        return rc, out, err

    def run_script(self, local_path, args="", sudo=True, timeout=180):
        """上传脚本到 /tmp 并执行，返回 (rc, out, err)"""
        remote = "/tmp/.md_%s" % os.path.basename(local_path)
        self.put(local_path, remote)
        cmd = "bash %s %s" % (remote, args)
        rc, out, err = self.run(cmd, timeout=timeout, sudo=sudo)
        self.run("rm -f %s" % remote, sudo=True)
        return rc, out, err

    # -- 传输 --
    def put(self, local, remote, progress=None):
        self.connect()

        def cb(done, total):
            if progress:
                progress(done, total)

        size = os.path.getsize(local)
        t0 = time.time()
        self.sftp.put(local, remote, callback=cb)
        dt = max(time.time() - t0, 0.001)
        return size, size / dt / 1024.0 / 1024.0

    def md5(self, remote, sudo=False):
        rc, out, _ = self.run("md5sum %s 2>/dev/null | awk '{print $1}'" % shlex.quote(remote),
                              sudo=sudo)
        return out.strip() if rc == 0 else ""

    def exists(self, remote):
        rc, _, _ = self.run("test -e %s" % shlex.quote(remote))
        return rc == 0


# ---------------------------------------------------------------- 探测
def probe(dev):
    rc, out, err = dev.run(
        "echo '### OS'; uname -a; "
        "echo '### IFACES'; ip -br a; "
        "echo '### ROUTE'; ip route; "
        "echo '### UDC'; ls /sys/class/udc 2>/dev/null; "
        "echo '### GADGET'; ls /sys/kernel/config/usb_gadget 2>/dev/null; "
        "echo '### PUB'; ls -l %s/Device %s/Core 2>/dev/null; "
        "echo '### TEST'; ls -l /home/cat/MegaTest 2>/dev/null; "
        "echo '### SVC'; systemctl is-enabled ntmega 2>/dev/null; systemctl is-active ntmega 2>/dev/null; "
        "echo '### PROCS'; pgrep -a -x Core; pgrep -a -x Device; "
        "echo '### PORTS'; ss -lntp 2>/dev/null | grep -E ':(1888|1889|5000|22)\\b'; "
        "echo '### RUNSH'; ls -l %s/run.sh %s/run.sh_bask 2>/dev/null; true" % (PUB_DIR, PUB_DIR, PUB_DIR, PUB_DIR),
        timeout=30)
    if not out.strip():
        raise RuntimeError("探测无输出: %s" % err.strip())
    return out


def parse_sections(text):
    sec, data = None, {}
    for line in text.splitlines():
        if line.startswith("### "):
            sec = line[4:].strip()
            data[sec] = []
        elif sec:
            data[sec].append(line)
    return {k: "\n".join(v).strip() for k, v in data.items()}


# ---------------------------------------------------------------- 虚拟网卡
VNIC_DIR = "/home/cat/mega_deploy"
VNIC_FILES = ["usb-switch.sh", "vnic_lib.sh", "vnic_up.sh", "vnic_down.sh",
              "vnic_boot.sh", "vnic_status.sh", "mega-vnic.service", "vnic_install.sh"]


def vnic_install(dev, start=False, uninstall=False):
    """把脚本装到 /home/cat/mega_deploy 并启用 mega-vnic.service"""
    if uninstall:
        rc, out, err = dev.run_script(os.path.join(SCRIPTS_DIR, "vnic_install.sh"),
                                      "--uninstall", sudo=True, timeout=120)
        return "UNINSTALL_OK" in out, out, err
    stage = "/tmp/mega_vnic_stage"
    dev.run("rm -rf %s && mkdir -p %s" % (stage, stage), check=True)
    for f in VNIC_FILES:
        dev.put(os.path.join(SCRIPTS_DIR, f), posixpath.join(stage, f))
    dev.run("chmod 755 %s/*.sh && chmod 644 %s/mega-vnic.service" % (stage, stage), check=True)
    args = "--start" if start else ""
    rc, out, err = dev.run("bash %s/vnic_install.sh %s" % (stage, args), sudo=True, timeout=300)
    dev.run("rm -rf %s" % stage, sudo=True)
    return "INSTALL_OK" in out, out, err


def vnic_up(dev, cidr="192.168.42.1/24", dhcp_ip="192.168.42.100", start=False):
    """设备侧开虚拟网卡：未安装则先安装（并启用开机自启）"""
    rc, _, _ = dev.run("test -x %s/vnic_up.sh" % VNIC_DIR)
    if rc != 0:
        info("  未检测到已安装的虚拟网卡环境，先执行安装 ...")
        ok, out, err = vnic_install(dev, start=False)
        info("  " + out.strip().replace("\n", "\n  "))
        if not ok:
            return False, out, err
    rc, out, err = dev.run("bash %s/vnic_up.sh %s %s" % (VNIC_DIR, cidr, dhcp_ip),
                           sudo=True, timeout=180)
    return "VNIC_OK" in out, out, err


def vnic_down(dev):
    rc, _, _ = dev.run("test -x %s/vnic_down.sh" % VNIC_DIR)
    if rc != 0:
        return False, "未安装虚拟网卡环境（先执行 vnic install）", ""
    rc, out, err = dev.run("bash %s/vnic_down.sh" % VNIC_DIR, sudo=True, timeout=180)
    return "VNIC_DOWN" in out, out, err


def vnic_status(dev):
    rc, _, _ = dev.run("test -x %s/vnic_status.sh" % VNIC_DIR)
    if rc == 0:
        rc, out, err = dev.run("bash %s/vnic_status.sh" % VNIC_DIR, timeout=30)
        return out or err
    rc, out, _ = dev.run(
        "echo '== IFACES'; ip -br a; "
        "echo '== GADGET'; ls /sys/kernel/config/usb_gadget/ 2>/dev/null; "
        "for g in /sys/kernel/config/usb_gadget/*/; do [ -d \"$g\" ] && "
        "echo \"$(basename $g): funcs=$(ls $g/functions 2>/dev/null | tr '\\n' ' ') UDC=$(cat $g/UDC 2>/dev/null)\"; done; "
        "echo '== STATE'; cat /sys/class/udc/*/state 2>/dev/null; "
        "echo '== UNIT'; systemctl is-enabled mega-vnic 2>/dev/null; "
        "systemctl is-active mega-vnic 2>/dev/null; true", timeout=20)
    return out


# ---------------------------------------------------------------- 部署
def deploy(dev, files, dest=PUB_DIR, restart=False, backup=True, dry_run=False,
           progress=True, stop_first=True):
    """files: list of logical names in PAYLOAD_MAP

    顺序: 停 Core/Device -> 备份 -> 上传校验 -> 落位 -> 恢复 run.sh -> 启服务 -> 验证
    """
    result = {"uploaded": [], "backup_dir": None, "runsh": None,
              "restart": None, "verify": None, "stopped": None}
    ts = datetime.now().strftime("%Y%m%d_%H%M%S")
    tmpdir = "/tmp/mega_deploy_%s" % ts

    # 0. 预检
    for name in files:
        local = os.path.join(PAYLOAD_DIR, PAYLOAD_MAP[name][0])
        if not os.path.exists(local):
            raise RuntimeError("本地载荷缺失: %s" % local)

    if dry_run:
        for name in files:
            local, rdir, _ = PAYLOAD_MAP[name]
            info("  [dry-run] %s -> %s/%s (%d B)" %
                 (name, rdir, local, os.path.getsize(os.path.join(PAYLOAD_DIR, local))))
        return result

    dev.connect()
    dev.run("mkdir -p %s" % tmpdir, check=True)

    # 0.5 先停 Core/Device（按“停止 -> 传输 -> 恢复”的顺序）
    if stop_first:
        rc, act, _ = dev.run("systemctl is-active ntmega")
        act = act.strip()
        dev.run("systemctl stop ntmega", sudo=True, timeout=60)
        dev.run("pkill -x Core ; pkill -x Device", sudo=True)
        time.sleep(1)
        rc2, left, _ = dev.run("(pgrep -x Core; pgrep -x Device) | wc -l")
        result["stopped"] = "service=%s, residual=%s" % (act, left.strip())
        info("  已停止 ntmega (原状态 %s)，残留进程 %s 个" % (act, left.strip()))

    # 1. 备份
    if backup:
        bdir = posixpath.join(dest, "backup_%s" % ts)
        dev.run("mkdir -p %s" % bdir, sudo=True)
        for name in files:
            _, rdir, _ = PAYLOAD_MAP[name]
            target = posixpath.join(rdir, name)
            if dev.exists(target):
                dev.run("cp -a %s %s/" % (shlex.quote(target), bdir), sudo=True)
        ok, out, _ = dev.run("ls -l %s | tail -n +2" % bdir, sudo=True)
        result["backup_dir"] = bdir
        info("  备份 -> %s" % bdir)

    # 2. 上传
    for idx, name in enumerate(files, 1):
        local_name, rdir, _ = PAYLOAD_MAP[name]
        local = os.path.join(PAYLOAD_DIR, local_name)
        remote_tmp = posixpath.join(tmpdir, name)
        size = os.path.getsize(local)
        info("  上传 %-9s %8.2f MB ..." % (name, size / 1048576.0))
        last = [0]

        def cb(done, total, _n=name, _last=last):
            if not progress:
                return
            pct = int(done * 100 / max(total, 1))
            if pct // 10 > _last[0] // 10 or done == total:
                _last[0] = pct
                sys.stdout.write("\r    %s %3d%%  %.1f/%.1f MB" %
                                 (_n, pct, done / 1048576.0, total / 1048576.0))
                sys.stdout.flush()

        n, mbps = dev.put(local, remote_tmp, cb)
        if progress:
            sys.stdout.write("  (%.1f MB/s)\n" % mbps)
            sys.stdout.flush()
        remote_md5 = dev.md5(remote_tmp)
        import hashlib
        h = hashlib.md5()
        with open(local, "rb") as f:
            for chunk in iter(lambda: f.read(1 << 20), b""):
                h.update(chunk)
        local_md5 = h.hexdigest()
        if remote_md5 != local_md5:
            raise RuntimeError("%s 上传校验失败: local=%s remote=%s" % (name, local_md5, remote_md5))
        info("    md5 %s OK" % local_md5[:12])

        # 3. 落位（先落 .new 再 mv，减少半包窗口）
        target = posixpath.join(rdir, name)
        dev.run("mkdir -p %s" % rdir, sudo=True)
        dev.run("install -m 755 %s %s.new && mv -f %s.new %s"
                % (remote_tmp, target, target, target), sudo=True, check=True)
        result["uploaded"].append({"name": name, "path": target, "md5": local_md5})

    dev.run("rm -rf %s" % tmpdir, sudo=True)

    # 4. 恢复 run.sh（pub 里缺失时）
    rc, _, _ = dev.run("test -f %s/run.sh" % dest)
    if rc != 0:
        rc2, _, _ = dev.run("test -f %s/run.sh_bask" % dest)
        if rc2 == 0:
            dev.run("cp -a %s/run.sh_bask %s/run.sh && chmod +x %s/run.sh"
                    % (dest, dest, dest), sudo=True, check=True)
            result["runsh"] = "restored from run.sh_bask"
            info("  已恢复 run.sh（来自 run.sh_bask）")
        else:
            result["runsh"] = "missing (no run.sh_bask)"
            info("  ⚠ 未找到 run.sh 与 run.sh_bask，无法通过 ntmega 启动")
    else:
        result["runsh"] = "present"

    # 5. 恢复服务（应停止后启动；--no-block 防止 oneshot 脚本常驻阻塞调用）
    if restart:
        dev.run("systemctl daemon-reload", sudo=True)
        rc, out, err = dev.run("systemctl start --no-block ntmega", sudo=True, timeout=60)
        time.sleep(5)
        rc2, act, _ = dev.run("systemctl is-active ntmega")
        result["restart"] = "start rc=%d state=%s %s" % (rc, act.strip(), (err or out).strip()[:160])
        info("  ntmega start rc=%d state=%s" % (rc, act.strip()))

    # 6. 验证
    result["verify"] = verify(dev)
    return result


def verify(dev, wait=2):
    time.sleep(wait)
    rc, out, _ = dev.run(
        "echo '### ACTIVE'; systemctl is-active ntmega; "
        "echo '### PROCS'; pgrep -a -x Core; pgrep -a -x Device; "
        "echo '### PORTS'; ss -lntp 2>/dev/null | grep -E ':(1888|1889|5000)'; "
        "echo '### CORE_LOG'; tail -n 8 %s/log/core.log 2>/dev/null; "
        "echo '### DEV_LOG'; tail -n 5 %s/log/device.log 2>/dev/null; "
        "echo '### BOOT_LOG'; tail -n 6 %s/log/system_startup.log 2>/dev/null" % (PUB_DIR, PUB_DIR, PUB_DIR),
        timeout=30)
    return parse_sections(out)


def svc(dev, action):
    if action == "status":
        return verify(dev, wait=0)
    if action in ("enable", "disable"):
        rc, out, err = dev.run("systemctl %s ntmega" % action, sudo=True, timeout=60)
        return {"rc": rc, "msg": (err or out).strip(), "state": verify(dev, 0)}
    if action in ("start", "stop", "restart"):
        rc, out, err = dev.run("systemctl %s --no-block ntmega" % action, sudo=True, timeout=60)
        time.sleep(3 if action != "stop" else 1)
        return {"rc": rc, "msg": (err or out).strip(), "state": verify(dev, 0)}
    raise ValueError(action)


def tail_logs(dev, n=40, log="core"):
    path = posixpath.join(PUB_DIR, "log", "%s.log" % log)
    rc, out, err = dev.run("tail -n %d %s" % (n, path), timeout=20)
    return out if rc == 0 else err


# ---------------------------------------------------------------- PC 侧提示
def pc_rndis_adapters():
    """列出 Windows 上疑似 RNDIS 的网卡（只读）"""
    try:
        import subprocess
        ps = ("Get-NetAdapter | Where-Object {$_.InterfaceDescription -match 'RNDIS|USB Ethernet'} "
              "| Select-Object Name,InterfaceDescription,Status,ifIndex | Format-Table -AutoSize")
        r = subprocess.run(["powershell", "-NoProfile", "-Command", ps],
                           capture_output=True, text=True, timeout=20)
        return (r.stdout or r.stderr).strip()
    except Exception as e:
        return "(无法查询: %s)" % e


def pc_alias_cmd(pc_ip="192.168.42.2", prefix=24, if_index=None):
    if if_index:
        return "netsh interface ip set address name=\"%s\" static %s 255.255.255.0" % (if_index, pc_ip)
    return "netsh interface ip set address name=\"<RNDIS网卡名>\" static %s 255.255.255.0" % pc_ip


# ---------------------------------------------------------------- CLI
def build_parser():
    p = argparse.ArgumentParser(
        prog="mega_deploy",
        description="Mega 设备部署工具：虚拟网卡环境 + Core/MegaTest 部署",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog=__doc__)
    sub = p.add_subparsers(dest="cmd")

    sub.add_parser("list", help="列出配置中的设备")

    sp = sub.add_parser("probe", help="探测设备环境")
    sp.add_argument("--ip", required=True)
    sp.add_argument("--user"); sp.add_argument("--password"); sp.add_argument("--port", type=int)

    sp = sub.add_parser("vnic", help="虚拟网卡 install/uninstall/up/down/status")
    sp.add_argument("action", choices=["install", "uninstall", "up", "down", "status"])
    sp.add_argument("--ip", required=True)
    sp.add_argument("--vnic-ip", default="192.168.42.1/24")
    sp.add_argument("--dhcp-ip", default="192.168.42.100")
    sp.add_argument("--start", action="store_true", help="install 后立即启动")
    sp.add_argument("--user"); sp.add_argument("--password"); sp.add_argument("--port", type=int)

    sp = sub.add_parser("deploy", help="上传并部署二进制")
    sp.add_argument("--ip", required=True)
    sp.add_argument("--files", default="Device,Core,MegaTest")
    sp.add_argument("--dest", default=PUB_DIR)
    sp.add_argument("--restart", action="store_true")
    sp.add_argument("--no-backup", action="store_true")
    sp.add_argument("--dry-run", action="store_true")
    sp.add_argument("--user"); sp.add_argument("--password"); sp.add_argument("--port", type=int)

    sp = sub.add_parser("svc", help="服务控制")
    sp.add_argument("action", choices=["start", "stop", "restart", "status", "enable", "disable"])
    sp.add_argument("--ip", required=True)
    sp.add_argument("--user"); sp.add_argument("--password"); sp.add_argument("--port", type=int)

    sp = sub.add_parser("logs", help="查看日志")
    sp.add_argument("--ip", required=True)
    sp.add_argument("-n", type=int, default=40)
    sp.add_argument("--log", default="core", choices=["core", "device", "system_startup"])
    sp.add_argument("--user"); sp.add_argument("--password"); sp.add_argument("--port", type=int)

    sp = sub.add_parser("pc", help="PC 侧 RNDIS 网卡查看/设置")
    sp.add_argument("--apply", action="store_true", help="执行 netsh 设置（需管理员）")
    sp.add_argument("--pc-ip", default="192.168.42.2")

    sub.add_parser("web", help="启动 Web 控制台")

    return p


def main(argv=None):
    args = build_parser().parse_args(argv)

    if args.cmd == "list":
        cfg = load_config()
        info("%-22s %-18s %-8s %s" % ("名称", "IP", "用户", "备注"))
        info("-" * 70)
        for d in cfg.get("devices", []):
            info("%-22s %-18s %-8s %s" % (d.get("name", ""), d.get("host", ""),
                                          d.get("user", "cat"), d.get("note", "")))
        return 0

    if args.cmd == "web":
        import mega_web
        mega_web.serve()
        return 0

    if args.cmd == "pc":
        info(pc_rndis_adapters())
        info("\n设置 PC 侧 RNDIS 网卡 IP（管理员 PowerShell/cmd）:")
        info("  " + pc_alias_cmd(args.pc_ip))
        return 0

    if not getattr(args, "ip", None):
        build_parser().print_help()
        return 1

    dev = MegaDevice(args.ip, getattr(args, "user", None),
                     getattr(args, "password", None), getattr(args, "port", None))
    t0 = time.time()
    try:
        dev.connect()
        info("已连接 %s@%s" % (dev.user, dev.host))

        if args.cmd == "probe":
            sec = parse_sections(probe(dev))
            for k in ("OS", "IFACES", "ROUTE", "UDC", "GADGET", "PUB", "TEST",
                      "SVC", "PROCS", "PORTS", "RUNSH"):
                info("\n== %s ==" % k)
                info(sec.get(k, "(空)"))

        elif args.cmd == "vnic":
            if args.action in ("install", "uninstall"):
                ok, out, err = vnic_install(dev, start=args.start,
                                            uninstall=(args.action == "uninstall"))
                info(out.strip())
                if err.strip():
                    info("[stderr] " + err.strip())
                if not ok:
                    return 2
            elif args.action == "up":
                ok, out, err = vnic_up(dev, args.vnic_ip, args.dhcp_ip, args.start)
                info(out.strip())
                if err.strip():
                    info("[stderr] " + err.strip())
                if not ok:
                    return 2
                info("\nPC 侧提示: RNDIS 网卡应已出现（USB Ethernet/RNDIS），"
                     "若未自动取址请设为 %s/24 或重启网卡走 DHCP" % args.dhcp_ip)
                info("  当前 PC 网卡:")
                info("  " + pc_rndis_adapters().replace("\n", "\n  "))
            elif args.action == "down":
                ok, out, err = vnic_down(dev)
                info(out.strip())
                if err.strip():
                    info("[stderr] " + err.strip())
                if not ok:
                    return 2
            else:
                info(vnic_status(dev))

        elif args.cmd == "deploy":
            files = [f.strip() for f in args.files.split(",") if f.strip()]
            bad = [f for f in files if f not in PAYLOAD_MAP]
            if bad:
                info("未知文件: %s（可选: %s）" % (",".join(bad), ",".join(PAYLOAD_MAP)))
                return 1
            info("目标目录: %s   文件: %s" % (args.dest, ",".join(files)))
            res = deploy(dev, files, dest=args.dest, restart=args.restart,
                         backup=not args.no_backup, dry_run=args.dry_run)
            if args.dry_run:
                return 0
            info("\n== 部署结果 ==")
            for u in res["uploaded"]:
                info("  %-9s -> %s  md5 %s" % (u["name"], u["path"], u["md5"]))
            info("  run.sh : %s" % res["runsh"])
            if res["restart"]:
                info("  restart: %s" % res["restart"])
            v = res["verify"] or {}
            info("\n== 运行状态 ==")
            for k in ("ACTIVE", "PROCS", "PORTS"):
                info("  %-8s %s" % (k + ":", (v.get(k) or "(空)").replace("\n", " | ")))
            info("\n== core.log 末尾 ==")
            info("  " + (v.get("CORE_LOG") or "(无)").replace("\n", "\n  "))

        elif args.cmd == "svc":
            r = svc(dev, args.action)
            if args.action == "status":
                for k in ("ACTIVE", "PROCS", "PORTS"):
                    info("  %-8s %s" % (k + ":", (r.get(k) or "(空)").replace("\n", " | ")))
            else:
                info("rc=%s %s" % (r["rc"], r["msg"]))
                st = r["state"]
                info("  ACTIVE: %s" % (st.get("ACTIVE") or "").strip())
                info("  PORTS : %s" % (st.get("PORTS") or "(空)").replace("\n", " | "))

        elif args.cmd == "logs":
            info(tail_logs(dev, args.n, args.log))

    except Exception as e:
        info("\n[错误] %s" % e)
        return 3
    finally:
        dev.close()
        info("\n耗时 %.1fs" % (time.time() - t0))
    return 0


if __name__ == "__main__":
    sys.exit(main())
