MEGAS 系统文件覆盖式升级包 v9.9.22 / RNDIS + sshd 加固（含重启）
===============================================================

⚠️ 本包为测试产物（fake: true）。相对 v9.9.21 的唯一变化：
   **新增 etc/ssh/sshd_config.d/99-megas-ota.conf 与 ssh_harden.sh**，
   在「覆盖系统文件」之后、「重启」之前把 sshd 的并发/超时参数加固，
   解决 OTA 重启循环后 SSH 报 `Exceeded MaxStartups` / banner timeout 的问题。
   其余 RNDIS 部署内容与 v9.9.21 完全一致，未改动任何 RNDIS 文件。

v9.9.22 升级链路（runUpdate-sys.sh，须 root 或免密 sudo）：
  1. GitHub 拉 Firmware-MegaS-9.9.22.zip + sha256，比对哈希
  2. unzip 到 /tmp/rndis_upgrade/
  3. deploy_sys.sh --apply：备份到 /home/cat/pub/backup_sys_<ts>/，逐文件原子覆盖 + md5 校验
     （本步同时落地 /etc/ssh/sshd_config.d/99-megas-ota.conf）
  4. 激活：systemctl daemon-reload / enable mega-vnic.service / nmcli connection reload
  5. **ssh_harden.sh（新增）**：确保主配置首行有 Include；`sshd -t` 语法校验 +
     `sshd -T` 实际生效值校验；失败即回滚 sshd_config 并终止升级（不重启，保证不变砖）
  6. deploy_sys.sh --verify 复核落地文件
  7. **setsid 延迟 3s 执行 systemctl reboot**（脱离 SSH 会话，保证重启一定发出）
     重启后 sshd 以新配置启动，MaxStartups 从 10:30:100 提升到 100:30:200
  8. 状态写 /home/cat/rndis_upgrade_state
     （BOOT_BEFORE / BACKUP / SHA256 / SSH_HARDEN / SSH_EFF / STATUS / REBOOT）
  9. 上位机轮询设备重新上线，以 boot_id 变化确认重启，再跑验收清单

  加 --no-reboot 可只覆盖不重启（deploy_sys.sh 本身永远不重启）。
  回退：sh deploy_sys.sh <root> --rollback /home/cat/pub/backup_sys_<ts>

一、包结构（系统 tree，覆盖根 = /）
----------------------------------
  Firmware-MegaS-9.9.22/
  ├── etc/
  │   ├── systemd/system/mega-vnic.service
  │   ├── NetworkManager/system-connections/mega-vnic-usb0.nmconnection
  │   └── ssh/sshd_config.d/99-megas-ota.conf     ★ v9.9.22 新增
  ├── home/cat/mega_deploy/                        7 个 RNDIS 脚本
  ├── deploy_sys.sh           覆盖式升级执行器（默认 DRY-RUN）
  ├── ssh_harden.sh           ★ v9.9.22 新增：sshd 加固 + 校验 + 自动回滚
  ├── runUpdate-sys.sh        升级入口（默认 9.9.22，含重启）
  ├── manifest.json           文件清单 / 权限 / 目标路径
  ├── README.txt              本文件
  └── pc-tools/               PC 侧上位机软件（不覆盖到系统）

  deploy_sys.sh 只遍历白名单目录（etc/home/usr/opt/var/lib/bin/sbin），
  manifest/README/pc-tools/ssh_harden.sh 等根级脚本不会被写进系统。

二、★ v9.9.22 新增：sshd 加固（为什么需要）
------------------------------------------
  现象（2026-11-26 实证）：系统升级脚本每轮 `systemctl reboot` 后，设备在线
  （ICMP 0% 丢包、TCP22 握手成功），但 sshd 不发 banner；paramiko 报
  `No existing session` / `Error reading SSH protocol banner`。原始 socket 探测
  抓到 sshd 明确回 **`Exceeded MaxStartups`**。

  根因：sshd 默认 `MaxStartups 10:30:100`。热重启不清空连接状态，加上编排脚本
  密集重试产生的未认证连接不释放（PC 侧可见大量 `FIN_WAIT_2`），占满槽位后
  sshd 主动拒绝/静默丢弃新连接。RTC 回退 → NTP 大幅前跳时钟
  （`who -b`=1970-01-01、ssh.service "since 2024-06-18 … 2 years ago"）
  又让 `LoginGraceTime` 一类基于时间的清理异常，加剧堆积。
  完全断电上电能清空连接表与 sshd 子进程，但只是干净窗口，密集连接会复发。

  加固值（/etc/ssh/sshd_config.d/99-megas-ota.conf）：
      UseDNS no
      MaxStartups 100:30:200
      LoginGraceTime 30

  安全设计：
   - OpenSSH「首个获得的值生效」→ ssh_harden.sh 保证 Include 在主配置首行；
     若 drop-in 未生效，自动注释主配置里同名显式项并在末尾追加三行。
   - 任何一步都用 `sshd -t` 校验语法；再用 `sshd -T` 校验实际生效值。
   - 校验失败 → 从 `.bak.megas-ota.<ts>` 还原主配置 → 打印 SSH_HARDEN_FAIL
     → runUpdate-sys.sh die（写 STATUS=FAIL，**不重启**），设备仍能 SSH 登录。
   - drop-in 走 deploy_sys.sh 的备份/manifest，可用 --rollback 整包回退。

三、RNDIS 部署内容汇总（来自既有记忆与 E:\mega\rndis）
------------------------------------------------------
  平台：LubanCat-2IO / RK3568 / Ubuntu 20.04.6 / 内核 4.19.232
  gadget：固定复用 /sys/kernel/config/usb_gadget/g1，UDC=fcc00000.dwc3
  ★ 设计铁律：绝不 mkdir/rmdir gadget 目录。Rockchip 4.19 的 android_usb
    补丁只允许一个 gadget；建第二个会 ENOMEM，且失败清理会触发内核 Oops。
  切换方式：解绑 UDC -> 功能级增删（uvc.0 <-> rndis.0）-> 重新绑 UDC。
  VID/PID：0x1d6b / 0x0104（原 0x0525/0xa4a2 会被本机 oem16.inf 抢绑整机）。
  网络：设备 usb0=192.168.42.1/24，dnsmasq 给 PC 分 192.168.42.100/24；
    NM 专用 manual profile（never-default）防 DHCP 冲掉静态 IP。
  开机：mega-vnic.service（Type=oneshot, RemainAfterExit=yes, After=network.target），
    脚本内限时等 g1 + 三级自愈（replug -> dwc3 unbind/bind -> 兜底回绑）。
  已知坑：NM 自动生成 DHCP 档冲掉静态 IP；kill -0 对 root 进程 EPERM 误判；
    切 UVC->RNDIS 后 state=not attached 需 replug。

四、上位机软件
--------------
  E:\demo\mega_deploy\ —— PC 侧轻量部署工具，已随包附在 pc-tools/。
    形态：Python CLI + 本地 Web 控制台（http://127.0.0.1:8765）
    传输：paramiko SFTP，带进度 + 逐文件 md5 校验
    快速开始：run_gui.bat 打开控制台；run_cli.bat probe --ip <IP>
    载荷：Device/Core/MegaTest 二进制本包【未包含】（属应用升级，非系统环境）。

五、deploy_sys.sh 用法
----------------------
  sh deploy_sys.sh <payload_root>                     # DRY-RUN
  sh deploy_sys.sh <payload_root> --apply            # 备份 + 原子覆盖 + md5
  sh deploy_sys.sh <payload_root> --verify  <backup> # 校验已落地文件
  sh deploy_sys.sh <payload_root> --rollback <backup># 整包回退（含删除新增文件）
  权限：*.sh=755，*.service=644，*.nmconnection=600，其它=644。
  ★ 服务激活与 sshd 加固不在本脚本内，由 runUpdate-sys.sh 显式执行。

六、版本关系
------------
  v9.9.16 = MCU A/B 双槽 OTA 包（进度条 + 抗干扰 + 回退）
  v9.9.21 = 系统文件覆盖 / RNDIS 环境（含重启）
  v9.9.22 = 本包（v9.9.21 + sshd 加固），十轮含重启压测目标版本
  共用同一仓库与 Firmware-MegaS-<ver>.zip 命名，靠版本号区分，互不覆盖。
